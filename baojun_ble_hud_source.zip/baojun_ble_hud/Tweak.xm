#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <objc/runtime.h>

// ============================================================
// MARK: - 前向声明
// ============================================================

@interface BJTick : NSObject
+ (instancetype)shared;
- (void)onTick;
@end

// ============================================================
// MARK: - 全局变量
// ============================================================

static UIView *gCard = nil;
static UILabel *gValues[8];
static UILabel *gTimeLabel = nil;
static NSDateFormatter *gFmt = nil;
static BOOL gTimerStarted = NO;
static BOOL gInjected = NO;

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

// ============================================================
// MARK: - 读取车辆状态
// ============================================================

static NSDictionary *BJReadStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) sd = val;
        else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) { id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil]; if ([p isKindOfClass:[NSDictionary class]]) sd = p; }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

// ============================================================
// MARK: - 更新卡片数值
// ============================================================

static void BJUpdateCard(void) {
    if (!gCard) return;
    NSDictionary *sd = BJReadStatus();
    if (!sd) return;

    NSString *keys[] = {@"batSOH", @"batterySoc", @"current", @"batAvgTemp", @"voltage", @"lowBatVol", @"interiorTemperature", @"autoGearStatus"};

    for (int i = 0; i < 8; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        if (i == 2) gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]];
        else if (i == 3 || i == 6) gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]];
        else if (i == 4 || i == 5) gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]];
        else if (i == 7) {
            NSInteger g = [val integerValue];
            gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
        }
        else gValues[i].text = [NSString stringWithFormat:@"%@%%", val];
    }

    if (gTimeLabel) {
        NSString *t = sd[@"collectTime"] ?: @"--";
        if ([t length] >= 19) t = [t substringFromIndex:11];
        gTimeLabel.text = [NSString stringWithFormat:@"数据更新: %@", t];
    }
}

// ============================================================
// MARK: - 创建卡片 (仿官方模块风格)
// ============================================================

static UIView *BJCreateCard(void) {
    if (gCard) return gCard;

    gFmt = [[NSDateFormatter alloc] init];
    gFmt.dateFormat = @"HH:mm:ss";

    CGFloat cardW = 280;
    CGFloat cardH = 130;

    gCard = [[UIView alloc] initWithFrame:CGRectMake(0, 0, cardW, cardH)];
    gCard.backgroundColor = [UIColor whiteColor];
    gCard.layer.cornerRadius = 12;
    gCard.layer.shadowColor = [UIColor blackColor].CGColor;
    gCard.layer.shadowOffset = CGSizeMake(0, 1);
    gCard.layer.shadowRadius = 8;
    gCard.layer.shadowOpacity = 0.06;

    // 标题
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(16, 10, 200, 16)];
    title.text = @"车辆状态";
    title.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    title.textColor = [UIColor blackColor];
    [gCard addSubview:title];

    // 分割线
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(16, 30, cardW - 32, 0.5)];
    sep.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.06];
    [gCard addSubview:sep];

    // 两列布局
    CGFloat startY = 36;
    CGFloat rowH = 18;
    CGFloat colW = (cardW - 32) / 2;

    struct { NSString *icon; NSString *label; int tag; CGFloat x; CGFloat y; } rows[] = {
        {@"heart.fill",         @"电池健康", 0, 16,  startY},
        {@"bolt.fill",          @"电池电量", 1, 16,  startY + rowH},
        {@"waveform.path.ecg",  @"电池电流", 2, 16,  startY + rowH*2},
        {@"thermometer.medium", @"电池温度", 3, 16,  startY + rowH*3},
        {@"bolt.circle.fill",   @"电池电压", 4, colW+16, startY},
        {@"car.2.fill",         @"电瓶电压", 5, colW+16, startY + rowH},
        {@"thermometer.medium", @"车内温度", 6, colW+16, startY + rowH*2},
        {@"gearshape",          @"档位",     7, colW+16, startY + rowH*3},
    };

    for (int i = 0; i < 8; i++) {
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(rows[i].x, rows[i].y + 2, 12, 12)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:9 weight:UIFontWeightRegular]];
            icon.tintColor = [UIColor systemGrayColor];
        }
        [gCard addSubview:icon];

        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 16, rows[i].y, 56, rowH)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:10];
        lbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.45];
        [gCard addSubview:lbl];

        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 72, rows[i].y, colW - 88, rowH)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor blackColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [gCard addSubview:gValues[i]];
    }

    // 底部分割线
    UIView *sep2 = [[UIView alloc] initWithFrame:CGRectMake(16, startY + rowH*4 + 4, cardW - 32, 0.5)];
    sep2.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.06];
    [gCard addSubview:sep2];

    // 数据更新时间
    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, startY + rowH*4 + 8, cardW - 32, 12)];
    gTimeLabel.font = [UIFont systemFontOfSize:9];
    gTimeLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    gTimeLabel.text = @"数据更新: --";
    [gCard addSubview:gTimeLabel];

    return gCard;
}

// ============================================================
// MARK: - 寻找合适的注入容器
// ============================================================

static UIView *BJFindContainer(UIView *view, int depth) {
    if (depth > 10 || !view) return nil;

    CGRect frame = view.frame;
    CGFloat screenH = [UIScreen mainScreen].bounds.size.height;

    // 检查是否是合适的容器:
    // 1. 足够大（能放下卡片）
    // 2. 有背景色（说明是可视容器）
    // 3. 在屏幕中间区域

    BOOL isLargeEnough = frame.size.width > 200 && frame.size.height > 150;
    BOOL isInMiddle = frame.origin.y > 100 && frame.origin.y < screenH - 200;
    BOOL hasBackground = view.backgroundColor && CGColorGetAlpha(view.backgroundColor.CGColor) > 0.1;

    if (isLargeEnough && isInMiddle && hasBackground) {
        NSLog(@"[BJBLE] 找到候选容器: %@ frame={{%.0f,%.0f,%.0f,%.0f}} bg=%@",
            NSStringFromClass([view class]), frame.origin.x, frame.origin.y, frame.size.width, frame.size.height,
            view.backgroundColor);
        return view;
    }

    // 递归搜索子视图
    for (UIView *sub in view.subviews) {
        UIView *found = BJFindContainer(sub, depth + 1);
        if (found) return found;
    }

    return nil;
}

// ============================================================
// MARK: - 注入到合适的容器
// ============================================================

static void BJInjectToContainer(UIView *container) {
    if (!container || gInjected) return;

    UIView *card = BJCreateCard();

    // 计算位置 - 放在容器的底部区域
    CGFloat containerW = container.bounds.size.width;
    CGFloat containerH = container.bounds.size.height;
    CGFloat cardW = card.bounds.size.width;
    CGFloat cardH = card.bounds.size.height;

    // 居中放置
    CGFloat x = (containerW - cardW) / 2;
    CGFloat y = containerH - cardH - 16; // 底部留16pt

    card.frame = CGRectMake(x, y, cardW, cardH);

    [container addSubview:card];
    gInjected = YES;

    BJUpdateCard();

    // 定时刷新
    if (!gTimerStarted) {
        gTimerStarted = YES;
        [[NSRunLoop currentRunLoop] addTimer:
            [NSTimer scheduledTimerWithTimeInterval:3.0
                target:[BJTick shared] selector:@selector(onTick)
                userInfo:nil repeats:YES]
            forMode:NSRunLoopCommonModes];
    }

    NSLog(@"[BJBLE] 卡片已注入到容器: %@", NSStringFromClass([container class]));
}

// ============================================================
// MARK: - 递归查找并注入
// ============================================================

static void BJRecursiveInject(UIView *view, int depth) {
    if (depth > 15 || !view || gInjected) return;

    CGRect frame = view.frame;
    CGFloat screenH = [UIScreen mainScreen].bounds.size.height;

    // 检查当前视图是否是合适的容器
    BOOL isLargeEnough = frame.size.width > 200 && frame.size.height > 100;
    BOOL isInScreen = frame.origin.y >= 0 && frame.origin.y + frame.size.height <= screenH + 50;
    BOOL hasSubviews = view.subviews.count > 0;

    if (isLargeEnough && isInScreen && hasSubviews && !gInjected) {
        // 检查是否有背景色
        if (view.backgroundColor) {
            CGFloat alpha = CGColorGetAlpha(view.backgroundColor.CGColor);
            if (alpha > 0.05) {
                NSLog(@"[BJBLE] 找到容器 depth=%d: %@ {{%.0f,%.0f,%.0f,%.0f}} subviews=%lu",
                    depth, NSStringFromClass([view class]),
                    frame.origin.x, frame.origin.y, frame.size.width, frame.size.height,
                    (unsigned long)view.subviews.count);
                BJInjectToContainer(view);
                return;
            }
        }
    }

    // 递归搜索
    for (UIView *sub in view.subviews) {
        BJRecursiveInject(sub, depth + 1);
    }
}

// ============================================================
// MARK: - 定时器
// ============================================================

@implementation BJTick
+ (instancetype)shared { static BJTick *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJTick new]; }); return o; }
- (void)onTick { dispatch_async(dispatch_get_main_queue(), ^{ BJUpdateCard(); }); }
@end

// ============================================================
// MARK: - Hooks
// ============================================================

// Hook UIViewController - 每次页面出现时搜索容器
%hook UIViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJIsTarget() || gInjected) return;

    NSLog(@"[BJBLE] UIViewController viewDidAppear: %@", NSStringFromClass([self class]));

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (gInjected) return;
            NSLog(@"[BJBLE] 开始搜索容器...");
            BJRecursiveInject(self.view, 0);

            // 如果没找到合适的容器，注入到 keyWindow
            if (!gInjected) {
                NSLog(@"[BJBLE] 未找到合适容器，注入到 keyWindow");
                UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
                for (UIWindow *w in [UIApplication sharedApplication].windows) {
                    if (w.isKeyWindow) { keyWindow = w; break; }
                }
#pragma clang diagnostic pop
                if (keyWindow) BJInjectToContainer(keyWindow);
            }
        });
}
%end

// Hook NSUserDefaults - 数据更新时刷新
%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ BJUpdateCard(); });
    }
}
%end

// ============================================================
// MARK: - 入口
// ============================================================

%ctor {
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] ====== 宝骏云海 HUD 已加载 (容器注入模式) ======");
}
