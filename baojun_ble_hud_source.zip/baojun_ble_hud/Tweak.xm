#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

%ctor {
    @autoreleasepool {
        NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
        NSLog(@"[BJBLE] ====== 插件加载 bid=%@ ======", bid);

        if (![bid isEqualToString:@"com.sgmw.baojunplus"]) {
            NSLog(@"[BJBLE] 不是目标App，跳过");
            return;
        }

        NSLog(@"[BJBLE] 是目标App，启动延时探测");

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)),
            dispatch_get_main_queue(), ^{
                NSLog(@"[BJBLE] 延时触发，弹出 Alert");

                UIWindow *kw = nil;
                for (UIWindow *w in [UIApplication sharedApplication].windows) {
                    if (w.isKeyWindow) { kw = w; break; }
                }

                if (!kw) {
                    NSLog(@"[BJBLE] 没找到 keyWindow");
                    return;
                }

                NSLog(@"[BJBLE] 找到 keyWindow: %@", kw);

                UIAlertController *alert = [UIAlertController
                    alertControllerWithTitle:@"Tweak OK"
                    message:[NSString stringWithFormat:@"bid=%@\nkeyWindow=%@", bid, kw]
                    preferredStyle:UIAlertControllerStyleAlert];

                [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                    style:UIAlertActionStyleDefault handler:nil]];

                [kw.rootViewController presentViewController:alert animated:YES completion:nil];
                NSLog(@"[BJBLE] Alert 已弹出");
            });
    }
}
