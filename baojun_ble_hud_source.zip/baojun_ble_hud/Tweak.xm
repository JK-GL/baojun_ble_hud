#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface BJPanHandler : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
@end

@interface BJTick : NSObject
+ (instancetype)shared;
- (void)onTick;
@end

static UIView *gHUD = nil;
static NSDateFormatter *gFmt = nil;

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

// ============================================================
// MARK: - 创建一行: [SF图标 + 标签 + 数值]
// ============================================================

static UIView *BJMakeRow(NSString *iconName, NSString *label, NSString *value, CGFloat y) {
    UIView *row = [[UIView alloc] initWithFrame:CGRectMake(0, y, 200, 22)];

    // SF Symbol 图标
    UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(4, 1, 18, 18)];
    UIImage *img = [UIImage systemImageNamed:iconName];
    if (img) {
        icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:12 weight:UIFontWeightRegular]];
        icon.tintColor = [UIColor systemBlueColor];
    }
    [row addSubview:icon];

    // 标签
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(26, 2, 70, 16)];
    lbl.text = label;
    lbl.font = [UIFont systemFontOfSize:11];
    lbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
    [row addSubview:lbl];

    // 数值
    UILabel *val = [[UILabel alloc] initWithFrame:CGRectMake(100, 2, 96, 16)];
    val.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightMedium];
    val.textColor = [UIColor blackColor];
    val.textAlignment = NSTextAlignmentRight;
    val.text = value;
    val.tag = 100; // 用 tag 标记，方便后续更新
    [row addSubview:val];

    return row;
}

// ============================================================
// MARK: - 读取车辆状态
// ============================================================

static NSDictionary *BJReadStatusDict(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) sd = val;
        else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) { id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil]; if ([p isKindOfClass:[NSDictionary class]]) sd = p; }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

// ============================================================
// MARK: - 显示 HUD
// ============================================================

static void BJShowHUD(void) {
    if (gHUD) return;
    gFmt = [[NSDateFormatter alloc] init];
    gFmt.dateFormat = @"HH:mm:ss";

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;

    // 卡片容器
    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - 216, 60, 208, 260)];
    gHUD.backgroundColor = [[UIColor colorWithWhite:0.96 alpha:0.92] colorWithAlphaComponent:0.92];
    gHUD.layer.cornerRadius = 18;
    gHUD.layer.shadowColor = [UIColor blackColor].CGColor;
    gHUD.layer.shadowOffset = CGSizeMake(0, 4);
    gHUD.layer.shadowRadius = 16;
    gHUD.layer.shadowOpacity = 0.12;

    // 标题栏
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 208, 36)];
    header.backgroundColor = [UIColor clearColor];
    [gHUD addSubview:header];

    // SF Symbol 标题图标
    UIImageView *carIcon = [[UIImageView alloc] initWithFrame:CGRectMake(12, 8, 20, 20)];
    UIImage *carImg = [UIImage systemImageNamed:@"car.fill"];
    if (carImg) {
        carIcon.image = [carImg imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:14 weight:UIFontWeightSemibold]];
        carIcon.tintColor = [UIColor systemGreenColor];
    }
    [header addSubview:carIcon];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(36, 8, 120, 20)];
    title.text = @"宝骏云海";
    title.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    title.textColor = [UIColor blackColor];
    [header addSubview:title];

    // 分割线
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(12, 36, 184, 0.5)];
    sep.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.08];
    [gHUD addSubview:sep];

    // 8 行数据 - 用 SF Symbols
    CGFloat y = 44;
    CGFloat gap = 24;

    NSDictionary *sd = BJReadStatusDict();
    NSString *soh = sd[@"batSOH"] ? [NSString stringWithFormat:@"%@%%", sd[@"batSOH"]] : @"--";
    NSString *soc = sd[@"batterySoc"] ? [NSString stringWithFormat:@"%@%%", sd[@"batterySoc"]] : @"--";
    NSString *cur = sd[@"current"] ? [NSString stringWithFormat:@"%.1fA", [sd[@"current"] doubleValue]] : @"--A";
    NSString *btmp = sd[@"batAvgTemp"] ? [NSString stringWithFormat:@"%.0f°C", [sd[@"batAvgTemp"] doubleValue]] : @"--°C";
    NSString *volt = sd[@"voltage"] ? [NSString stringWithFormat:@"%.1fV", [sd[@"voltage"] doubleValue]] : @"--V";
    NSString *lbv = sd[@"lowBatVol"] ? [NSString stringWithFormat:@"%.1fV", [sd[@"lowBatVol"] doubleValue]] : @"--V";
    NSString *itemp = sd[@"interiorTemperature"] ? [NSString stringWithFormat:@"%.0f°C", [sd[@"interiorTemperature"] doubleValue]] : @"--°C";
    NSInteger gear = [sd[@"autoGearStatus"] integerValue];
    NSString *gearStr = @"?";
    if (gear == 10) gearStr = @"P";
    else if (gear == 20) gearStr = @"R";
    else if (gear == 30) gearStr = @"N";
    else if (gear == 40) gearStr = @"D";

    [gHUD addSubview:BJMakeRow(@"heart.fill",         @"电池健康", soh,  y += gap)];
    [gHUD addSubview:BJMakeRow(@"bolt.fill",          @"电池电量", soc,  y += gap)];
    [gHUD addSubview:BJMakeRow(@"waveform.path.ecg",  @"电池电流", cur,  y += gap)];
    [gHUD addSubview:BJMakeRow(@"thermometer.medium", @"电池温度", btmp, y += gap)];
    [gHUD addSubview:BJMakeRow(@"bolt.circle.fill",   @"电池电压", volt, y += gap)];
    [gHUD addSubview:BJMakeRow(@"car.2.fill",         @"电瓶电压", lbv,  y += gap)];
    [gHUD addSubview:BJMakeRow(@"thermometer.medium", @"车内温度", itemp,y += gap)];
    [gHUD addSubview:BJMakeRow(@"gearshape",          @"档位",     gearStr, y += gap)];

    // 底部时间
    UIView *footer = [[UIView alloc] initWithFrame:CGRectMake(0, 244, 208, 16)];
    [gHUD addSubview:footer];

    UIView *sep2 = [[UIView alloc] initWithFrame:CGRectMake(12, 0, 184, 0.5)];
    sep2.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.08];
    [footer addSubview:sep2];

    UILabel *timeLbl = [[UILabel alloc] initWithFrame:CGRectMake(12, 2, 184, 12)];
    timeLbl.font = [UIFont systemFontOfSize:9];
    timeLbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    timeLbl.text = [NSString stringWithFormat:@"更新: %@", [gFmt stringFromDate:[NSDate date]]];
    timeLbl.tag = 200;
    [footer addSubview:timeLbl];

    // 添加到窗口
    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop
    if (keyWindow) [keyWindow addSubview:gHUD];

    // 拖拽
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]
        initWithTarget:[BJPanHandler shared] action:@selector(handlePan:)];
    [gHUD addGestureRecognizer:pan];

    NSLog(@"[BJBLE] HUD 已显示");
}

// ============================================================
// MARK: - 刷新 HUD 数值
// ============================================================

static void BJRefreshValues(void) {
    if (!gHUD) return;
    NSDictionary *sd = BJReadStatusDict();
    if (!sd) return;

    for (UIView *sub in gHUD.subviews) {
        for (UIView *row in sub.subviews) {
            if ([row isKindOfClass:[UILabel class]] && row.tag == 100) {
                // 根据位置判断是哪一行
                UILabel *valLabel = (UILabel *)row;
                CGFloat y = row.frame.origin.y;
                NSString *key = @"";
                if (y < 70) key = @"batSOH";
                else if (y < 94) key = @"batterySoc";
                else if (y < 118) key = @"current";
                else if (y < 142) key = @"batAvgTemp";
                else if (y < 166) key = @"voltage";
                else if (y < 190) key = @"lowBatVol";
                else if (y < 214) key = @"interiorTemperature";
                else if (y < 240) key = @"autoGearStatus";

                if (sd[key]) {
                    if ([key isEqualToString:@"current"]) valLabel.text = [NSString stringWithFormat:@"%.1fA", [sd[key] doubleValue]];
                    else if ([key isEqualToString:@"batAvgTemp"] || [key isEqualToString:@"interiorTemperature"]) valLabel.text = [NSString stringWithFormat:@"%.0f°C", [sd[key] doubleValue]];
                    else if ([key isEqualToString:@"voltage"] || [key isEqualToString:@"lowBatVol"]) valLabel.text = [NSString stringWithFormat:@"%.1fV", [sd[key] doubleValue]];
                    else if ([key isEqualToString:@"autoGearStatus"]) {
                        NSInteger g = [sd[key] integerValue];
                        if (g == 10) valLabel.text = @"P";
                        else if (g == 20) valLabel.text = @"R";
                        else if (g == 30) valLabel.text = @"N";
                        else if (g == 40) valLabel.text = @"D";
                        else valLabel.text = [NSString stringWithFormat:@"%ld", (long)g];
                    }
                    else valLabel.text = [NSString stringWithFormat:@"%@%%", sd[key]];
                }
            }
        }
    }

    // 更新时间
    for (UIView *sub in gHUD.subviews) {
        for (UIView *item in sub.subviews) {
            if ([item isKindOfClass:[UILabel class]] && item.tag == 200) {
                ((UILabel *)item).text = [NSString stringWithFormat:@"更新: %@", [gFmt stringFromDate:[NSDate date]]];
            }
        }
    }
}

// ============================================================
// MARK: - 定时器 + 拖拽
// ============================================================

@implementation BJTick
+ (instancetype)shared { static BJTick *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJTick new]; }); return o; }
- (void)onTick { dispatch_async(dispatch_get_main_queue(), ^{ BJRefreshValues(); }); }
@end

@implementation BJPanHandler
+ (instancetype)shared { static BJPanHandler *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJPanHandler new]; }); return o; }
- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGFloat w = g.view.bounds.size.width, h = g.view.bounds.size.height;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width, sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(MAX(w/2, MIN(loc.x, sx-w/2)), MAX(40+h/2, MIN(loc.y, sy-h-40)));
    }
}
@end

// ============================================================
// MARK: - Logos Hooks
// ============================================================

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ BJRefreshValues(); });
    }
}
%end

%hook CBPeripheral
- (void)peripheral:(CBPeripheral *)peripheral
    didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic
                              error:(NSError *)error {
    %orig;
    if (!BJIsTarget() || error) return;
    if ([characteristic.UUID.UUIDString isEqualToString:@"2A7F"]) {
        NSLog(@"[BJBLE] 控制数据 %luB", (unsigned long)characteristic.value.length);
    }
}
%end

// ============================================================
// MARK: - 入口
// ============================================================

%ctor {
    if (!BJIsTarget()) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
            dispatch_get_main_queue(), ^{
                BJShowHUD();
                [[NSRunLoop currentRunLoop] addTimer:
                    [NSTimer scheduledTimerWithTimeInterval:3.0 target:[BJTick shared]
                        selector:@selector(onTick) userInfo:nil repeats:YES]
                    forMode:NSRunLoopCommonModes];
            });
    });
}
