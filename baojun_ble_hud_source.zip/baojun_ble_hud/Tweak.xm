#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <objc/runtime.h>

// ============================================================
// MARK: - 前向声明
// ============================================================

@interface BJPanHandler : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
@end

@interface FlutterViewController : UIViewController
@end

// ============================================================
// MARK: - 全局变量
// ============================================================

static UIView *gCardView = nil;
static UILabel *gValues[8]; // 8个数值标签
static NSDateFormatter *gFmt = nil;

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

// ============================================================
// MARK: - 读取车辆状态
// ============================================================

static NSDictionary *BJReadStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) sd = val;
        else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) { id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil]; if ([p isKindOfClass:[NSDictionary class]]) sd = p; }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

// ============================================================
// MARK: - 创建仿官方风格卡片
// ============================================================

static UIView *BJCreateCard(void) {
    if (gCardView) return gCardView;

    // 卡片背景 - 半透明毛玻璃风格
    gCardView = [[UIView alloc] initWithFrame:CGRectMake(12, 50, 200, 180)];
    gCardView.backgroundColor = [UIColor colorWithWhite:0.12 alpha:0.88];
    gCardView.layer.cornerRadius = 16;
    gCardView.layer.shadowColor = [UIColor blackColor].CGColor;
    gCardView.layer.shadowOffset = CGSizeMake(0, 4);
    gCardView.layer.shadowRadius = 20;
    gCardView.layer.shadowOpacity = 0.4;
    gCardView.clipsToBounds = NO;

    CGFloat y = 10;
    CGFloat rowH = 20;

    // 标题行
    UIImageView *carIcon = [[UIImageView alloc] initWithFrame:CGRectMake(12, y, 16, 16)];
    UIImage *carImg = [UIImage systemImageNamed:@"car.fill"];
    if (carImg) {
        carIcon.image = [carImg imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:11 weight:UIFontWeightMedium]];
        carIcon.tintColor = [UIColor systemGreenColor];
    }
    [gCardView addSubview:carIcon];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(30, y - 1, 100, 16)];
    title.text = @"宝骏云海";
    title.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    title.textColor = [UIColor whiteColor];
    [gCardView addSubview:title];

    y += rowH + 4;

    // 分割线
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(12, y, 176, 0.5)];
    sep.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.15];
    [gCardView addSubview:sep];
    y += 6;

    // 数据行定义: [SF Symbol, 标签, 值, tag]
    struct { NSString *icon; NSString *label; int tag; } rows[] = {
        {@"heart.fill",        @"电池健康", 0},
        {@"bolt.fill",         @"电池电量", 1},
        {@"waveform.path.ecg", @"电池电流", 2},
        {@"thermometer.medium",@"电池温度", 3},
        {@"bolt.circle.fill",  @"电池电压", 4},
        {@"car.2.fill",        @"电瓶电压", 5},
        {@"thermometer.medium",@"车内温度", 6},
        {@"gearshape",         @"档位",     7},
    };

    for (int i = 0; i < 8; i++) {
        // SF Symbol 图标
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(12, y + 2, 14, 14)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:10 weight:UIFontWeightRegular]];
            icon.tintColor = [UIColor colorWithWhite:1.0 alpha:0.5];
        }
        [gCardView addSubview:icon];

        // 标签
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(30, y, 70, rowH)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:10];
        lbl.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.6];
        [gCardView addSubview:lbl];

        // 数值
        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(106, y, 82, rowH)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor whiteColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        gValues[i].tag = rows[i].tag;
        [gCardView addSubview:gValues[i]];

        y += rowH;
    }

    // 底部分割线
    UIView *sep2 = [[UIView alloc] initWithFrame:CGRectMake(12, y, 176, 0.5)];
    sep2.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.15];
    [gCardView addSubview:sep2];
    y += 4;

    // 刷新时间
    UILabel *timeLbl = [[UILabel alloc] initWithFrame:CGRectMake(12, y, 176, 12)];
    timeLbl.font = [UIFont systemFontOfSize:8];
    timeLbl.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.35];
    timeLbl.text = @"更新: --";
    timeLbl.tag = 100;
    [gCardView addSubview:timeLbl];

    // 拖拽手势
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]
        initWithTarget:[BJPanHandler shared] action:@selector(handlePan:)];
    [gCardView addGestureRecognizer:pan];

    return gCardView;
}

// ============================================================
// MARK: - 更新卡片数值
// ============================================================

static void BJUpdateCard(void) {
    if (!gCardView) return;
    NSDictionary *sd = BJReadStatus();
    if (!sd) return;

    // 数值映射
    NSString *keys[] = {@"batSOH", @"batterySoc", @"current", @"batAvgTemp", @"voltage", @"lowBatVol", @"interiorTemperature", @"autoGearStatus"};

    for (int i = 0; i < 8; i++) {
        id val = sd[keys[i]];
        if (!val) continue;

        if (i == 2) { // 电流
            gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]];
        } else if (i == 3 || i == 6) { // 温度
            gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]];
        } else if (i == 4 || i == 5) { // 电压
            gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]];
        } else if (i == 7) { // 档位
            NSInteger g = [val integerValue];
            if (g == 10) gValues[i].text = @"P";
            else if (g == 20) gValues[i].text = @"R";
            else if (g == 30) gValues[i].text = @"N";
            else if (g == 40) gValues[i].text = @"D";
            else gValues[i].text = [NSString stringWithFormat:@"%ld", (long)g];
        } else { // 百分比
            gValues[i].text = [NSString stringWithFormat:@"%@%%", val];
        }
    }

    // 更新时间
    for (UIView *sub in gCardView.subviews) {
        if ([sub isKindOfClass:[UILabel class]] && sub.tag == 100) {
            ((UILabel *)sub).text = [NSString stringWithFormat:@"更新: %@", [gFmt stringFromDate:[NSDate date]]];
        }
    }
}

// ============================================================
// MARK: - 定时器 + 拖拽
// ============================================================

@interface BJTick : NSObject
+ (instancetype)shared;
- (void)onTick;
@end
@implementation BJTick
+ (instancetype)shared { static BJTick *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJTick new]; }); return o; }
- (void)onTick { dispatch_async(dispatch_get_main_queue(), ^{ BJUpdateCard(); }); }
@end

@interface BJPanHandler : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
@end
@implementation BJPanHandler
+ (instancetype)shared { static BJPanHandler *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJPanHandler new]; }); return o; }
- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGFloat w = g.view.bounds.size.width, h = g.view.bounds.size.height;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width, sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(MAX(w/2, MIN(loc.x, sx-w/2)), MAX(40+h/2, MIN(loc.y, sy-h-40)));
    }
}
@end

// ============================================================
// MARK: - Hook FlutterViewController - 注入到 App 内部
// ============================================================

%hook FlutterViewController

- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJIsTarget()) return;

    // 检查是否已经注入
    if ([self.view viewWithTag:9999]) return;

    NSLog(@"[BJBLE] FlutterViewController viewDidAppear, 注入卡片");

    // 延时 1 秒等 Flutter 渲染完成
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            // 创建并注入卡片
            UIView *card = BJCreateCard();
            card.tag = 9999;
            [self.view addSubview:card];

            // 更新数据
            BJUpdateCard();

            // 启动定时刷新
            [[NSRunLoop currentRunLoop] addTimer:
                [NSTimer scheduledTimerWithTimeInterval:3.0 target:[BJTick shared]
                    selector:@selector(onTick) userInfo:nil repeats:YES]
                forMode:NSRunLoopCommonModes];

            NSLog(@"[BJBLE] 卡片已注入到 FlutterViewController");
        });
}

%end

// ============================================================
// MARK: - NSUserDefaults Hook - 实时更新
// ============================================================

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ BJUpdateCard(); });
    }
}
%end

// ============================================================
// MARK: - 入口
// ============================================================

%ctor {
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] ====== 宝骏云海 HUD 已加载 (注入模式) ======");

    gFmt = [[NSDateFormatter alloc] init];
    gFmt.dateFormat = @"HH:mm:ss";
}
