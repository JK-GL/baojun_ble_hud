#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    NSLog(@"[BJBLE] viewDidAppear bid=%@", bid);
    if (![bid isEqualToString:@"com.sgmw.baojunplus"]) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            CGFloat sw = [UIScreen mainScreen].bounds.size.width;
            UIView *hud = [[UIView alloc] initWithFrame:CGRectMake(sw-180, 80, 170, 200)];
            hud.backgroundColor = [UIColor whiteColor];
            hud.layer.cornerRadius = 14;
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 150, 180)];
            lbl.text = @"Tweak OK";
            lbl.textColor = [UIColor blackColor];
            lbl.font = [UIFont boldSystemFontOfSize:20];
            [hud addSubview:lbl];
            UIWindow *kw = nil;
            for (UIWindow *w in [UIApplication sharedApplication].windows) {
                if (w.isKeyWindow) { kw = w; break; }
            }
            if (kw) [kw addSubview:hud];
            NSLog(@"[BJBLE] HUD added");
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    NSLog(@"[BJBLE] appActive bid=%@", bid);
    if (![bid isEqualToString:@"com.sgmw.baojunplus"]) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            CGFloat sw = [UIScreen mainScreen].bounds.size.width;
            UIView *hud = [[UIView alloc] initWithFrame:CGRectMake(sw-180, 80, 170, 200)];
            hud.backgroundColor = [UIColor whiteColor];
            hud.layer.cornerRadius = 14;
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 150, 180)];
            lbl.text = @"Tweak OK";
            lbl.textColor = [UIColor blackColor];
            lbl.font = [UIFont boldSystemFontOfSize:20];
            [hud addSubview:lbl];
            UIWindow *kw = nil;
            for (UIWindow *w in [UIApplication sharedApplication].windows) {
                if (w.isKeyWindow) { kw = w; break; }
            }
            if (kw) [kw addSubview:hud];
            NSLog(@"[BJBLE] HUD added");
        });
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] loaded bid=%@", [NSBundle mainBundle].bundleIdentifier);
    }
}
