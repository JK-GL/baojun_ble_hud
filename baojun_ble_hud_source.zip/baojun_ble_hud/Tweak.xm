#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

static UIWindow *gKeyWindow = nil;

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;

    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    NSLog(@"[BJBLE] bundleId=%@", bid);
    if (![bid isEqualToString:@"com.sgmw.baojunplus"]) return;

    // 找到 keyWindow
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { gKeyWindow = w; break; }
    }
    if (!gKeyWindow) { NSLog(@"[BJBLE] no keyWindow"); return; }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            UIAlertController *alert = [UIAlertController
                alertControllerWithTitle:@"Tweak OK"
                message:@"点击查看视图层级"
                preferredStyle:UIAlertControllerStyleAlert];

            [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault
                handler:^(UIAlertAction *action) {
                    NSMutableString *log = [NSMutableString string];
                    for (UIWindow *w in [UIApplication sharedApplication].windows) {
                        [log appendFormat:@"Window: %@ {{%.0f,%.0f,%.0f,%.0f}} sub=%lu\n",
                            NSStringFromClass([w class]),
                            w.frame.origin.x, w.frame.origin.y,
                            w.frame.size.width, w.frame.size.height,
                            (unsigned long)w.subviews.count];
                        for (UIView *v in w.subviews) {
                            [log appendFormat:@"  %@ {{%.0f,%.0f,%.0f,%.0f}} sub=%lu\n",
                                NSStringFromClass([v class]),
                                v.frame.origin.x, v.frame.origin.y,
                                v.frame.size.width, v.frame.size.height,
                                (unsigned long)v.subviews.count];
                        }
                    }

                    UIAlertController *logAlert = [UIAlertController
                        alertControllerWithTitle:@"Views"
                        message:log
                        preferredStyle:UIAlertControllerStyleAlert];
                    [logAlert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
                    [gKeyWindow.rootViewController presentViewController:logAlert animated:YES completion:nil];
                }];

            [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
            [gKeyWindow.rootViewController presentViewController:alert animated:YES completion:nil];
        });
}
%end

%ctor {
    NSLog(@"[BJBLE] loaded bid=%@", [NSBundle mainBundle].bundleIdentifier);
}
