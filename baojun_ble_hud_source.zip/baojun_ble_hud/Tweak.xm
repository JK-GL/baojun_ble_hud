#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

// ============================================================
// MARK: - 全局变量
// ============================================================

static UIView *gHUD = nil;
static UILabel *gLabel = nil;

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

// ============================================================
// MARK: - 从 NSUserDefaults 读取车辆状态
// ============================================================

static NSString *BJReadCarStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        // 搜索包含 car_status 的 key
        if (![key containsString:@"car_status"] && ![key containsString:@"vehicle_status"]) continue;

        id val = dict[key];
        NSDictionary *sd = nil;

        if ([val isKindOfClass:[NSDictionary class]]) {
            sd = val;
        } else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) {
                id parsed = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil];
                if ([parsed isKindOfClass:[NSDictionary class]]) sd = parsed;
            }
        }

        if (!sd || !sd[@"batterySoc"]) continue;

        // 解析数值
        NSInteger soc = [sd[@"batterySoc"] integerValue];
        double leftPower = [sd[@"leftBatteryPower"] doubleValue];
        NSInteger leftMileage = [sd[@"leftMileage"] integerValue];
        NSInteger leftFuel = [sd[@"leftFuel"] integerValue];
        NSInteger mileage = [sd[@"mileage"] integerValue];
        NSInteger doorLock = [sd[@"doorLockStatus"] integerValue];
        NSInteger acOn = [sd[@"acStatus"] integerValue];
        double interiorTemp = [sd[@"interiorTemperature"] doubleValue];
        double batTemp = [sd[@"batAvgTemp"] doubleValue];
        double voltage = [sd[@"voltage"] doubleValue];
        double current = [sd[@"current"] doubleValue];
        NSInteger soh = [sd[@"batSOH"] integerValue];
        NSInteger charging = [sd[@"charging"] integerValue];
        NSString *time = sd[@"collectTime"] ?: @"--";

        // 档位
        NSInteger gear = [sd[@"autoGearStatus"] integerValue];
        NSString *gearStr = @"?";
        if (gear == 10) gearStr = @"P";
        else if (gear == 20) gearStr = @"R";
        else if (gear == 30) gearStr = @"N";
        else if (gear == 40) gearStr = @"D";

        // 拼装中文
        NSMutableString *h = [NSMutableString string];
        [h appendFormat:@"🔋 %ld%%  %.1fkWh", (long)soc, leftPower];
        if (charging) [h appendString:@" ⚡"];
        [h appendString:@"\n"];
        [h appendFormat:@"🛣️ 电%ldkm 油%ldkm\n", (long)leftMileage, (long)leftFuel];
        [h appendFormat:@"📊 总里程%ldkm\n", (long)mileage];
        [h appendFormat:@"⚡ %.0fV %.1fA SOH%ld%%\n", voltage, current, (long)soh];
        [h appendFormat:@"%@ %@\n", doorLock ? @"🔒已锁" : @"🔓未锁", acOn ? @"❄️开" : @"❄️关"];
        [h appendFormat:@"⚙️ 档位:%@  🌡️车%.0f°电%.0f°\n", gearStr, interiorTemp, batTemp];

        // 时间截取 HH:mm:ss
        NSString *shortTime = time;
        if ([time length] >= 19) shortTime = [time substringFromIndex:11];
        [h appendFormat:@"🕐 %@", shortTime];

        return [h copy];
    }
    return nil;
}

// ============================================================
// MARK: - HUD 刷新
// ============================================================

static void BJRefreshHUD(void) {
    if (!gLabel) return;
    NSString *status = BJReadCarStatus();
    if (status) {
        gLabel.text = status;
    }
}

// ============================================================
// MARK: - 定时器回调
// ============================================================

@interface BJTick : NSObject
+ (instancetype)shared;
- (void)onTick;
@end

@implementation BJTick
+ (instancetype)shared {
    static BJTick *o; static dispatch_once_t t;
    dispatch_once(&t, ^{ o = [BJTick new]; }); return o;
}
- (void)onTick {
    dispatch_async(dispatch_get_main_queue(), ^{
        BJRefreshHUD();
    });
}
@end

// ============================================================
// MARK: - 显示 HUD
// ============================================================

static void BJShowHUD(void) {
    if (gHUD) return;

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;

    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - 180, 60, 172, 200)];
    gHUD.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.88];
    gHUD.layer.cornerRadius = 14;
    gHUD.layer.borderWidth = 1;
    gHUD.layer.borderColor = [[UIColor colorWithRed:0.2 green:0.8 blue:0.4 alpha:0.8] CGColor];
    gHUD.tag = 8888;

    // 标题
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, 152, 18)];
    title.text = @"🚗 宝骏云海";
    title.textColor = [UIColor whiteColor];
    title.font = [UIFont boldSystemFontOfSize:13];
    [gHUD addSubview:title];

    // 分割线
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(10, 26, 152, 0.5)];
    sep.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.3];
    [gHUD addSubview:sep];

    // 内容
    gLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 30, 152, 160)];
    gLabel.textColor = [UIColor whiteColor];
    gLabel.font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightMedium];
    gLabel.numberOfLines = 0;
    gLabel.text = @"正在加载...";
    [gHUD addSubview:gLabel];

    // 找 keyWindow
    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop

    if (keyWindow) {
        [keyWindow addSubview:gHUD];
        NSLog(@"[BJBLE] HUD 已添加到 window: %@", keyWindow);
    } else {
        NSLog(@"[BJBLE] 未找到 keyWindow!");
    }
}

// ============================================================
// MARK: - Logos Hooks
// ============================================================

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"] || [defaultName containsString:@"vehicle"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            BJRefreshHUD();
        });
    }
}
%end

%hook CBPeripheral
- (void)peripheral:(CBPeripheral *)peripheral
    didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic
                              error:(NSError *)error {
    %orig;
    if (!BJIsTarget() || error) return;
    NSString *uuid = characteristic.UUID.UUIDString ?: @"";
    if ([uuid isEqualToString:@"2A7F"] || [uuid isEqualToString:@"2a7f"]) {
        NSLog(@"[BJBLE] 收到控制数据 %luB", (unsigned long)characteristic.value.length);
    }
}
%end

// ============================================================
// MARK: - 构造函数 - 插件入口
// ============================================================

%ctor {
    if (!BJIsTarget()) return;

    NSLog(@"[BJBLE] ====== 宝骏云海 BLE HUD 已加载 ======");
    NSLog(@"[BJBLE] Bundle: %@", [NSBundle mainBundle].bundleIdentifier);

    // 在主线程启动
    dispatch_async(dispatch_get_main_queue(), ^{
        // 延时 2 秒等 App 完全加载
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
            dispatch_get_main_queue(), ^{
                NSLog(@"[BJBLE] 开始显示 HUD");

                // 1. 显示 HUD
                BJShowHUD();

                // 2. 读取初始状态
                BJRefreshHUD();

                // 3. 如果没读到数据，显示提示
                if (gLabel && !gLabel.text.length) {
                    gLabel.text = @"等待数据...\n请打开宝骏App";
                }

                // 4. 启动定时刷新 (每3秒)
                [[NSRunLoop currentRunLoop] addTimer:
                    [NSTimer scheduledTimerWithTimeInterval:3.0
                        target:[BJTick shared]
                        selector:@selector(onTick)
                        userInfo:nil
                        repeats:YES]
                    forMode:NSRunLoopCommonModes];

                NSLog(@"[BJBLE] 定时刷新已启动");
            });
    });
}
