#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

static UIView *gHUD = nil;
static UIView *gCollapsed = nil;
static UIView *gExpanded = nil;
static UILabel *gValues[9] = {nil};
static UILabel *gTimeLabel = nil;
static UILabel *gKwhLabel = nil;
static UIImageView *gPillIcon = nil;
static NSDateFormatter *gDateFmt = nil;
static NSTimer *gPollTimer = nil;
static BOOL gIsTargetApp = NO;
static BOOL gIsExpanded = NO;

static BOOL BJCheckTarget(void) {
    if (gIsTargetApp) return YES;
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    gIsTargetApp = [bid isEqualToString:@"com.sgmw.baojunplus"] ||
                   [bid isEqualToString:@"com.cloudy.LingLingBang"];
    return gIsTargetApp;
}

static NSDictionary *BJReadCarStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        // Support both Baojun (car_status) and Wuling (CYUnifiedCarStatusInfosFor{VIN})
        BOOL match = [key containsString:@"car_status"] || [key containsString:@"CYUnifiedCarStatusInfosFor"];
        if (!match) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) {
            sd = val;
        } else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) {
                id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil];
                if ([p isKindOfClass:[NSDictionary class]]) sd = p;
            }
        }
        if (sd && sd[@"leftBatteryPower"]) {
            // Wuling app stores all values as strings, convert to numbers
            NSMutableDictionary *converted = [NSMutableDictionary dictionaryWithDictionary:sd];
            NSString *numKeys[] = {
                @"batSOH", @"leftBatteryPower", @"current", @"batAvgTemp",
                @"voltage", @"lowBatVol", @"interiorTemperature", @"autoGearStatus",
                @"keyStatus", @"strWhAng", @"batterySoc", @"mileage", @"leftMileage",
                @"oilLeftMileage", @"leftFuel", @"charging", @"acStatus",
                @"doorLockStatus", @"batMaxTemp", @"batMinTemp"
            };
            for (int i = 0; i < 20; i++) {
                id v = converted[numKeys[i]];
                if ([v isKindOfClass:[NSString class]] && [(NSString *)v length] > 0) {
                    NSNumberFormatter *nf = [[NSNumberFormatter alloc] init];
                    NSNumber *n = [nf numberFromString:v];
                    if (n) converted[numKeys[i]] = n;
                }
            }
            return [NSDictionary dictionaryWithDictionary:converted];
        }
    }
    return nil;
}

static void BJRefreshHUD(void) {
    if (!gHUD) return;
    NSDictionary *sd = BJReadCarStatus();
    if (!sd) return;

    NSString *keys[] = {
        @"batSOH", @"current", @"batAvgTemp",
        @"voltage", @"lowBatVol", @"interiorTemperature",
        @"keyStatus", @"strWhAng", @"autoGearStatus"
    };

    for (int i = 0; i < 9; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        switch (i) {
            case 1: gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]]; break;
            case 2: case 5: gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]]; break;
            case 3: case 4: gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]]; break;
            case 6: {
                NSInteger k = [val integerValue];
                gValues[i].text = (k==0)?@"已锁":(k==2)?@"在车":(k==1)?@"解锁":[NSString stringWithFormat:@"%ld",(long)k];
                break;
            }
            case 7: gValues[i].text = [NSString stringWithFormat:@"%.1f°", [val doubleValue]]; break;
            case 8: {
                NSInteger g = [val integerValue];
                gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
                break;
            }
            default: gValues[i].text = [NSString stringWithFormat:@"%@%%", val]; break;
        }
    }

    // Collapsed pill: icon color + icon switch, text stays white
    if (gKwhLabel && gPillIcon) {
        id kwh = sd[@"leftBatteryPower"];
        if (kwh) {
            gKwhLabel.text = [NSString stringWithFormat:@" %.1fkWh", [kwh doubleValue]];
            gKwhLabel.textColor = [UIColor whiteColor];
            double val = [kwh doubleValue];
            double pct = val / 20.0;
            UIColor *batColor;
            NSString *iconName;
            if (pct > 0.5) {
                batColor = [UIColor systemGreenColor];
                iconName = @"battery.100";
            } else if (pct > 0.2) {
                batColor = [UIColor systemYellowColor];
                iconName = @"battery.50";
            } else {
                batColor = [UIColor systemRedColor];
                iconName = @"battery.25";
            }
            gPillIcon.tintColor = batColor;
            UIImage *newImg = [UIImage systemImageNamed:iconName];
            if (newImg) {
                gPillIcon.image = [newImg imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:12 weight:UIFontWeightRegular]];
            }
        }
    }

    if (gTimeLabel && gDateFmt) {
        gTimeLabel.text = [NSString stringWithFormat:@"更新: %@", [gDateFmt stringFromDate:[NSDate date]]];
    }
}

static void BJToggleHUD(void);

@interface UIView (BJHUDPan)
- (void)bj_handlePan:(UIPanGestureRecognizer *)g;
- (void)bj_handleTap:(UITapGestureRecognizer *)g;
@end

@implementation UIView (BJHUDPan)
- (void)bj_handlePan:(UIPanGestureRecognizer *)g {
    CGPoint pt = [g translationInView:self.superview];
    self.center = CGPointMake(self.center.x + pt.x, self.center.y + pt.y);
    [g setTranslation:CGPointZero inView:self.superview];
    // Save position on drag end
    if (g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) {
        [[NSUserDefaults standardUserDefaults] setDouble:self.frame.origin.x forKey:@"bjble_hud_x"];
        [[NSUserDefaults standardUserDefaults] setDouble:self.frame.origin.y forKey:@"bjble_hud_y"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}
- (void)bj_handleTap:(UITapGestureRecognizer *)g {
    BJToggleHUD();
}
@end

static void BJScheduleTimer(void) {
    if (gPollTimer) return;
    gPollTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 repeats:YES block:^(NSTimer *t) {
        BJRefreshHUD();
    }];
}

static void BJCreateHUD(void) {
    if (gHUD) return;

    gDateFmt = [[NSDateFormatter alloc] init];
    gDateFmt.dateFormat = @"HH:mm:ss";

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;

    // --- Main container (restore saved position) ---
    CGFloat savedX = [[NSUserDefaults standardUserDefaults] doubleForKey:@"bjble_hud_x"];
    CGFloat savedY = [[NSUserDefaults standardUserDefaults] doubleForKey:@"bjble_hud_y"];
    CGFloat pillX = (savedX > 0 && savedY > 0) ? savedX : sw - 100;
    CGFloat pillY = (savedX > 0 && savedY > 0) ? savedY : 80;
    gHUD = [[UIView alloc] initWithFrame:CGRectMake(pillX, pillY, 90, 28)];
    gHUD.backgroundColor = [UIColor clearColor];
    gHUD.clipsToBounds = NO;

    // --- Collapsed pill ---
    gCollapsed = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 90, 28)];
    gCollapsed.backgroundColor = [UIColor colorWithWhite:0.15 alpha:0.55];
    gCollapsed.layer.cornerRadius = 14;
    gCollapsed.clipsToBounds = YES;

    // Subtle shadow
    gCollapsed.layer.shadowColor = [UIColor blackColor].CGColor;
    gCollapsed.layer.shadowOffset = CGSizeMake(0, 1);
    gCollapsed.layer.shadowRadius = 4;
    gCollapsed.layer.shadowOpacity = 0.3;
    gCollapsed.layer.masksToBounds = NO;

    // Thin border
    gCollapsed.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.15].CGColor;
    gCollapsed.layer.borderWidth = 0.5;

    // Battery SF Symbol icon
    gPillIcon = [[UIImageView alloc] initWithFrame:CGRectMake(8, 9, 22, 10)];
    UIImage *batImg = [UIImage systemImageNamed:@"battery.100"];
    if (batImg) {
        gPillIcon.image = [batImg imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:10 weight:UIFontWeightRegular]];
        gPillIcon.tintColor = [UIColor whiteColor];
    }
    gPillIcon.contentMode = UIViewContentModeScaleAspectFit;
    [gCollapsed addSubview:gPillIcon];

    gKwhLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 0, 58, 28)];
    gKwhLabel.font = [UIFont monospacedDigitSystemFontOfSize:10 weight:UIFontWeightBold];
    gKwhLabel.textColor = [UIColor whiteColor];
    gKwhLabel.textAlignment = NSTextAlignmentLeft;
    gKwhLabel.text = @" --kWh";
    [gCollapsed addSubview:gKwhLabel];

    // Tap to expand
    UITapGestureRecognizer *tapCollapse = [[UITapGestureRecognizer alloc] initWithTarget:gCollapsed action:@selector(bj_handleTap:)];
    [gCollapsed addGestureRecognizer:tapCollapse];

    // Drag pill
    UIPanGestureRecognizer *pillPan = [[UIPanGestureRecognizer alloc] initWithTarget:gHUD action:@selector(bj_handlePan:)];
    [gCollapsed addGestureRecognizer:pillPan];

    [gHUD addSubview:gCollapsed];

    // --- Expanded card (dark blur) ---
    CGFloat cardW = 155;
    CGFloat headerH = 24;
    CGFloat rowH = 20;
    CGFloat footerH = 16;
    CGFloat cardH = headerH + 9 * rowH + footerH + 6;

    gExpanded = [[UIView alloc] initWithFrame:CGRectMake(0, 0, cardW, cardH)];

    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark];
    UIVisualEffectView *blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
    blurView.frame = gExpanded.bounds;
    blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    blurView.layer.cornerRadius = 14;
    blurView.clipsToBounds = YES;
    [gExpanded addSubview:blurView];

    UIView *contentView = blurView.contentView;

    // Header: battery SF Symbol + kWh (centered, vertically aligned)
    UIImageView *hdrIcon = [[UIImageView alloc] initWithFrame:CGRectMake(cardW/2 - 26, 7, 22, 10)];
    UIImage *hdrImg = [UIImage systemImageNamed:@"battery.100"];
    if (hdrImg) {
        hdrIcon.image = [hdrImg imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:10 weight:UIFontWeightBold]];
        hdrIcon.tintColor = [UIColor whiteColor];
    }
    hdrIcon.contentMode = UIViewContentModeScaleAspectFit;
    hdrIcon.tag = 9002;
    [contentView addSubview:hdrIcon];

    UILabel *hdr = [[UILabel alloc] initWithFrame:CGRectMake(cardW/2 - 4, 4, 70, 16)];
    hdr.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightBold];
    hdr.textColor = [UIColor whiteColor];
    hdr.textAlignment = NSTextAlignmentLeft;
    hdr.tag = 9001;
    [contentView addSubview:hdr];

    UIView *sep1 = [[UIView alloc] initWithFrame:CGRectMake(6, headerH, cardW - 12, 0.5)];
    sep1.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.15];
    [contentView addSubview:sep1];

    // Data rows (9 items, no 电量 row)
    struct { NSString *icon; NSString *label; UIColor *color; } rows[] = {
        {@"heart.fill",      @"健康",   [UIColor systemPinkColor]},
        {@"waveform",        @"电流",   [UIColor systemTealColor]},
        {@"thermometer",     @"电池温", [UIColor systemOrangeColor]},
        {@"bolt.circle",     @"电池压", [UIColor systemYellowColor]},
        {@"car",             @"电瓶压", [UIColor systemBlueColor]},
        {@"sun.max",         @"车内温", [UIColor systemRedColor]},
        {@"key.fill",        @"钥匙",   [UIColor systemCyanColor]},
        {@"scope",           @"转角",   [UIColor systemIndigoColor]},
        {@"gearshape",       @"档位",   [UIColor systemPurpleColor]},
    };

    for (int i = 0; i < 9; i++) {
        CGFloat y = headerH + 2 + i * rowH;

        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(6, y + 3, 11, 11)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:7 weight:UIFontWeightMedium]];
            icon.tintColor = rows[i].color;
        }
        [contentView addSubview:icon];

        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(20, y + 1, 36, 16)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:8];
        lbl.textColor = [UIColor colorWithWhite:1.0 alpha:0.6];
        [contentView addSubview:lbl];

        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(58, y + 1, cardW - 66, 16)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:9 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor whiteColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [contentView addSubview:gValues[i]];
    }

    // Footer
    UIView *sep2 = [[UIView alloc] initWithFrame:CGRectMake(6, headerH + 9 * rowH + 2, cardW - 12, 0.5)];
    sep2.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.15];
    [contentView addSubview:sep2];

    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(6, headerH + 9 * rowH + 4, cardW - 12, footerH)];
    gTimeLabel.font = [UIFont systemFontOfSize:8];
    gTimeLabel.textColor = [UIColor colorWithWhite:1.0 alpha:0.4];
    gTimeLabel.text = @"更新: --:--:--";
    [contentView addSubview:gTimeLabel];

    gExpanded.hidden = YES;
    [gHUD addSubview:gExpanded];

    // Pan gesture on expanded
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:gHUD action:@selector(bj_handlePan:)];
    [gExpanded addGestureRecognizer:pan];

    // Tap anywhere on expanded to collapse
    UITapGestureRecognizer *tapExpand = [[UITapGestureRecognizer alloc] initWithTarget:gHUD action:@selector(bj_handleTap:)];
    [gExpanded addGestureRecognizer:tapExpand];

    // Add to keyWindow
    UIWindow *kw = nil;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { kw = w; break; }
    }
    if (kw) [kw addSubview:gHUD];

    BJRefreshHUD();
}

static void BJToggleHUD(void) {
    if (!gHUD || !gCollapsed || !gExpanded) return;
    gIsExpanded = !gIsExpanded;

    if (gIsExpanded) {
        CGFloat cardW = 155;
        CGFloat headerH = 24;
        CGFloat rowH = 20;
        CGFloat footerH = 16;
        CGFloat cardH = headerH + 9 * rowH + footerH + 6;

        // Expand downward from pill TOP edge
        CGFloat pillCX = gHUD.frame.origin.x + 45;
        CGFloat pillTopY = gHUD.frame.origin.y;

        gCollapsed.hidden = YES;
        gExpanded.hidden = NO;
        gHUD.frame = CGRectMake(pillCX - cardW/2, pillTopY, cardW, cardH);

        // Update header with kWh
        NSDictionary *sd = BJReadCarStatus();
        if (sd) {
            id kwh = sd[@"leftBatteryPower"];
            UILabel *hdr = (UILabel *)[gExpanded viewWithTag:9001];
            UIImageView *hIcon = (UIImageView *)[gExpanded viewWithTag:9002];
            if (hdr && kwh) hdr.text = [NSString stringWithFormat:@"%.1fkWh", [kwh doubleValue]];
            // Header icon color + switch based on battery level, text stays white
            if (hIcon && hdr) {
                double val = [kwh doubleValue];
                double pct = val / 20.0;
                UIColor *batColor;
                NSString *iconName;
                if (pct > 0.5) {
                    batColor = [UIColor systemGreenColor];
                    iconName = @"battery.100";
                } else if (pct > 0.2) {
                    batColor = [UIColor systemYellowColor];
                    iconName = @"battery.50";
                } else {
                    batColor = [UIColor systemRedColor];
                    iconName = @"battery.25";
                }
                hIcon.tintColor = batColor;
                hdr.textColor = [UIColor whiteColor];
                UIImage *newImg = [UIImage systemImageNamed:iconName];
                if (newImg) {
                    hIcon.image = [newImg imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:10 weight:UIFontWeightBold]];
                }
            }
            // Reposition icon+text centered, vertically aligned
            if (hIcon && hdr) {
                NSString *txt = hdr.text;
                CGFloat txtW = [txt sizeWithAttributes:@{NSFontAttributeName: hdr.font}].width;
                CGFloat totalW = 22 + 4 + txtW;
                CGFloat startX = (cardW - totalW) / 2;
                hIcon.frame = CGRectMake(startX, 7, 22, 10);
                hdr.frame = CGRectMake(startX + 26, 4, txtW + 4, 16);
            }
        }
        BJRefreshHUD();
    } else {
        // Collapse: pill top = expanded card top
        CGFloat pillCX = gHUD.frame.origin.x + gHUD.frame.size.width / 2;
        CGFloat cardTopY = gHUD.frame.origin.y;

        gCollapsed.hidden = NO;
        gExpanded.hidden = YES;
        gHUD.frame = CGRectMake(pillCX - 45, cardTopY, 90, 28);
        BJRefreshHUD();
    }
}

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJCheckTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
            BJScheduleTimer();
        });
}
%end

// Fallback for non-Flutter apps (e.g. Wuling LingLingBang)
%hook UIViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJCheckTarget()) return;
    if ([NSStringFromClass([self class]) containsString:@"FlutterViewController"]) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
            BJScheduleTimer();
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJCheckTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
        });
}
%end

// Hook NSUserDefaults for real-time car_status updates
%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!gIsTargetApp) return;
    if ([defaultName containsString:@"car_status"]) {
        // Lightweight: only schedule refresh, no parsing in hook
        dispatch_async(dispatch_get_main_queue(), ^{
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                BJRefreshHUD();
            });
        });
    }
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] v4.0 loaded %@", [NSBundle mainBundle].bundleIdentifier);
    }
}
