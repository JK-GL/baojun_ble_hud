#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <objc/runtime.h>

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

__attribute__((unused)) static NSString *BJHex(NSData *d, int mx) {
    if (!d) return @"";
    int len = (int)MIN(d.length, mx);
    const unsigned char *b = (const unsigned char *)d.bytes;
    NSMutableString *s = [NSMutableString stringWithCapacity:len*2];
    for (int i=0; i<len; i++) [s appendFormat:@"%02x",b[i]];
    return s;
}

static UIView *gHUD = nil;
static UILabel *gLabel = nil;

static void BJShowHUD(void) {
    if (gHUD) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        CGFloat sw = [UIScreen mainScreen].bounds.size.width;
        gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw-175, 80, 165, 110)];
        gHUD.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.85];
        gHUD.layer.cornerRadius = 12;
        gHUD.layer.borderWidth = 0.5;
        gHUD.layer.borderColor = [[UIColor colorWithRed:0.2 green:0.8 blue:0.4 alpha:0.8] CGColor];
        gLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, 6, 149, 98)];
        gLabel.textColor = [UIColor whiteColor];
        gLabel.font = [UIFont systemFontOfSize:10];
        gLabel.numberOfLines = 0;
        gLabel.text = @"Loading...";
        [gHUD addSubview:gLabel];
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        UIWindow *w = nil;
        for (UIWindow *win in [UIApplication sharedApplication].windows) {
            if (win.isKeyWindow) { w = win; break; }
        }
        if (!w) w = [UIApplication sharedApplication].windows.firstObject;
        if (w) [w addSubview:gHUD];
#pragma clang diagnostic pop
        NSLog(@"[BJBLE] HUD shown window=%@", w);
    });
}

static NSString *BJReadStatus(void) {
    NSDictionary *d = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *k in d) {
        id v = d[k];
        NSDictionary *sd = nil;
        if ([v isKindOfClass:[NSDictionary class]]) sd = v;
        else if ([v isKindOfClass:[NSString class]] && [(NSString *)v length] > 20) {
            NSData *jd = [(NSString *)v dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) { id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil]; if ([p isKindOfClass:[NSDictionary class]]) sd = p; }
        }
        if (!sd || (!sd[@"batterySoc"] && !sd[@"mileage"])) continue;
        NSMutableString *h = [NSMutableString string];
        [h appendFormat:@"Car Status\n"];
        [h appendFormat:@"SOC: %@%%\n", sd[@"batterySoc"]];
        [h appendFormat:@"Range: %@km EV / %@km Fuel\n", sd[@"leftMileage"], sd[@"leftFuel"]];
        [h appendFormat:@"Odometer: %@km\n", sd[@"mileage"]];
        [h appendFormat:@"Door: %@\n", [sd[@"doorLockStatus"] integerValue] ? @"LOCKED" : @"UNLOCKED"];
        [h appendFormat:@"AC: %@\n", [sd[@"acStatus"] integerValue] ? @"ON" : @"OFF"];
        [h appendFormat:@"Temp: %@C\n", sd[@"interiorTemperature"]];
        [h appendFormat:@"Time: %@", sd[@"collectTime"] ?: @"--"];
        return [h copy];
    }
    return nil;
}

@interface BJPanHandler : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
@end
@implementation BJPanHandler
+ (instancetype)shared { static BJPanHandler *h; static dispatch_once_t t; dispatch_once(&t, ^{ h = [BJPanHandler new]; }); return h; }
- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGFloat w = g.view.bounds.size.width, h = g.view.bounds.size.height;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width, sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(MAX(w/2, MIN(loc.x, sx-w/2)), MAX(40+h/2, MIN(loc.y, sy-h-40)));
    }
}
@end

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"] || [defaultName containsString:@"vehicle"]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            NSString *s = BJReadStatus();
            if (s && gLabel) gLabel.text = s;
        });
    }
}
%end

%ctor {
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] Loaded in %@", [NSBundle mainBundle].bundleIdentifier);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        BJShowHUD();
        NSString *s = BJReadStatus();
        if (s) gLabel.text = s;
        else gLabel.text = @"Waiting for data...\nOpen app to load";
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:[BJPanHandler shared] action:@selector(handlePan:)];
        [gHUD addGestureRecognizer:pan];
    });
}
