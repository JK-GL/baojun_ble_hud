#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <objc/runtime.h>

@interface BJTick : NSObject
+ (instancetype)shared;
- (void)onTick;
@end

static UIView *gCard = nil;
static UILabel *gValues[8];
static UILabel *gTimeLabel = nil;
static NSDateFormatter *gFmt = nil;
static BOOL gTimerStarted = NO;
static BOOL gInjected = NO;

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

static NSDictionary *BJReadStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) sd = val;
        else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) { id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil]; if ([p isKindOfClass:[NSDictionary class]]) sd = p; }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

static void BJUpdateCard(void) {
    if (!gCard) return;
    NSDictionary *sd = BJReadStatus();
    if (!sd) return;

    NSString *keys[] = {@"batSOH", @"batterySoc", @"current", @"batAvgTemp", @"voltage", @"lowBatVol", @"interiorTemperature", @"autoGearStatus"};

    for (int i = 0; i < 8; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        if (i == 2) gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]];
        else if (i == 3 || i == 6) gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]];
        else if (i == 4 || i == 5) gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]];
        else if (i == 7) {
            NSInteger g = [val integerValue];
            gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
        }
        else gValues[i].text = [NSString stringWithFormat:@"%@%%", val];
    }

    if (gTimeLabel) {
        NSString *t = sd[@"collectTime"] ?: @"--";
        if ([t length] >= 19) t = [t substringFromIndex:11];
        gTimeLabel.text = [NSString stringWithFormat:@"数据更新: %@", t];
    }
}

static void BJEnsureCard(void) {
    if (gCard) return;

    gFmt = [[NSDateFormatter alloc] init];
    gFmt.dateFormat = @"HH:mm:ss";

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;
    CGFloat sh = [UIScreen mainScreen].bounds.size.height;

    // 卡片宽度 - 和官方卡片一致（左右各留16pt）
    CGFloat cardW = sw - 32;
    CGFloat cardH = 120;

    // 固定位置 - 电量/空调卡片下方（约63%处）
    CGFloat cardX = 16;
    CGFloat cardY = sh * 0.63;

    gCard = [[UIView alloc] initWithFrame:CGRectMake(cardX, cardY, cardW, cardH)];
    gCard.backgroundColor = [UIColor whiteColor];
    gCard.layer.cornerRadius = 12;
    gCard.layer.shadowColor = [UIColor blackColor].CGColor;
    gCard.layer.shadowOffset = CGSizeMake(0, 1);
    gCard.layer.shadowRadius = 8;
    gCard.layer.shadowOpacity = 0.06;

    // 标题
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(16, 8, 200, 14)];
    title.text = @"车辆状态";
    title.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    title.textColor = [UIColor blackColor];
    [gCard addSubview:title];

    // 分割线
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(16, 26, cardW - 32, 0.5)];
    sep.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.06];
    [gCard addSubview:sep];

    // 两列布局
    CGFloat startY = 30;
    CGFloat rowH = 17;
    CGFloat colW = (cardW - 32) / 2;

    struct { NSString *icon; NSString *label; int tag; CGFloat x; CGFloat y; } rows[] = {
        {@"heart.fill",         @"电池健康", 0, 16,  startY},
        {@"bolt.fill",          @"电池电量", 1, 16,  startY + rowH},
        {@"waveform.path.ecg",  @"电池电流", 2, 16,  startY + rowH*2},
        {@"thermometer.medium", @"电池温度", 3, 16,  startY + rowH*3},
        {@"bolt.circle.fill",   @"电池电压", 4, colW+16, startY},
        {@"car.2.fill",         @"电瓶电压", 5, colW+16, startY + rowH},
        {@"thermometer.medium", @"车内温度", 6, colW+16, startY + rowH*2},
        {@"gearshape",          @"档位",     7, colW+16, startY + rowH*3},
    };

    for (int i = 0; i < 8; i++) {
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(rows[i].x, rows[i].y + 1, 11, 11)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:8 weight:UIFontWeightRegular]];
            icon.tintColor = [UIColor systemGrayColor];
        }
        [gCard addSubview:icon];

        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 14, rows[i].y, 52, rowH)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:9];
        lbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.45];
        [gCard addSubview:lbl];

        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 66, rows[i].y, colW - 82, rowH)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:10 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor blackColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [gCard addSubview:gValues[i]];
    }

    // 底部
    UIView *sep2 = [[UIView alloc] initWithFrame:CGRectMake(16, startY + rowH*4 + 2, cardW - 32, 0.5)];
    sep2.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.06];
    [gCard addSubview:sep2];

    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, startY + rowH*4 + 5, cardW - 32, 10)];
    gTimeLabel.font = [UIFont systemFontOfSize:8];
    gTimeLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    gTimeLabel.text = @"数据更新: --";
    [gCard addSubview:gTimeLabel];
}

static void BJInjectToKeyWindow(void) {
    if (gInjected) return;

    BJEnsureCard();
    if (!gCard) return;

    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop

    if (!keyWindow) return;
    if ([keyWindow viewWithTag:9999]) {
        BJUpdateCard();
        return;
    }

    [keyWindow addSubview:gCard];
    gInjected = YES;
    BJUpdateCard();

    if (!gTimerStarted) {
        gTimerStarted = YES;
        [[NSRunLoop currentRunLoop] addTimer:
            [NSTimer scheduledTimerWithTimeInterval:3.0
                target:[BJTick shared] selector:@selector(onTick)
                userInfo:nil repeats:YES]
            forMode:NSRunLoopCommonModes];
    }

    NSLog(@"[BJBLE] 卡片已注入到 keyWindow");
}

@implementation BJTick
+ (instancetype)shared { static BJTick *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJTick new]; }); return o; }
- (void)onTick { dispatch_async(dispatch_get_main_queue(), ^{ BJUpdateCard(); }); }
@end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJIsTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{ BJInjectToKeyWindow(); });
}
%end

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJIsTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{ BJInjectToKeyWindow(); });
}
%end

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ BJUpdateCard(); });
    }
}
%end

%ctor {
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] ====== 宝骏云海 HUD 已加载 (固定位置模式) ======");
}
