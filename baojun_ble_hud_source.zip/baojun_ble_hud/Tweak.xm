#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

static UIView *gOverlay = nil;

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.sgmw.baojunplus"]) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (gOverlay) return;

            CGFloat sw = [UIScreen mainScreen].bounds.size.width;
            CGFloat sh = [UIScreen mainScreen].bounds.size.height;

            gOverlay = [[UIView alloc] initWithFrame:CGRectMake(16, sh * 0.63, sw - 32, 120)];
            gOverlay.backgroundColor = [UIColor whiteColor];
            gOverlay.layer.cornerRadius = 12;

            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(8, 8, sw - 48, 100)];
            lbl.text = @"Tweak 已加载!\n可以显示视图层级";
            lbl.textColor = [UIColor blackColor];
            lbl.numberOfLines = 0;
            [gOverlay addSubview:lbl];

            UIWindow *kw = nil;
            for (UIWindow *w in [UIApplication sharedApplication].windows) {
                if (w.isKeyWindow) { kw = w; break; }
            }
            [kw addSubview:gOverlay];
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.sgmw.baojunplus"]) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (gOverlay) return;

            CGFloat sw = [UIScreen mainScreen].bounds.size.width;
            CGFloat sh = [UIScreen mainScreen].bounds.size.height;

            gOverlay = [[UIView alloc] initWithFrame:CGRectMake(16, sh * 0.63, sw - 32, 120)];
            gOverlay.backgroundColor = [UIColor whiteColor];
            gOverlay.layer.cornerRadius = 12;

            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(8, 8, sw - 48, 100)];
            lbl.text = @"Tweak 已加载!\n可以显示视图层级";
            lbl.textColor = [UIColor blackColor];
            lbl.numberOfLines = 0;
            [gOverlay addSubview:lbl];

            UIWindow *kw = nil;
            for (UIWindow *w in [UIApplication sharedApplication].windows) {
                if (w.isKeyWindow) { kw = w; break; }
            }
            [kw addSubview:gOverlay];
        });
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] 插件已加载 bid=%@", [NSBundle mainBundle].bundleIdentifier);
    }
}
