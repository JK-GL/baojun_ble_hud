#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BJGestureHandler : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
- (void)handlePinch:(UIPinchGestureRecognizer *)g;
- (void)handleDoubleTap:(UITapGestureRecognizer *)g;
@end

static UIView *gHUD = nil;
static UILabel *gValues[8] = {nil};
static UILabel *gTimeLabel = nil;
static UILabel *gLockIcon = nil;
static BOOL gLocked = NO;
static CGFloat gScale = 1.0;
static NSDateFormatter *gDateFmt = nil;
static NSTimer *gPollTimer = nil;

// 存储 key
static NSString *const kFrameKey = @"BJHUD_Frame_v1";
static NSString *const kScaleKey = @"BJHUD_Scale_v1";
static NSString *const kLockKey  = @"BJHUD_Lock_v1";

// ============================================================
// MARK: - 读取车辆状态
// ============================================================

static NSDictionary *BJReadCarStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) {
            sd = val;
        } else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) {
                id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil];
                if ([p isKindOfClass:[NSDictionary class]]) sd = p;
            }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

// ============================================================
// MARK: - 刷新 HUD
// ============================================================

static void BJRefreshHUD(void) {
    if (!gHUD) return;
    NSDictionary *sd = BJReadCarStatus();
    if (!sd) return;

    NSString *keys[] = {
        @"batSOH",           // 0: 电池健康
        @"batterySoc",       // 1: 电池电量
        @"current",          // 2: 电池电流
        @"batAvgTemp",       // 3: 电池温度
        @"voltage",          // 4: 电池电压
        @"lowBatVol",        // 5: 电瓶电压
        @"interiorTemperature", // 6: 车内温度
        @"autoGearStatus"    // 7: 档位
    };

    for (int i = 0; i < 8; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        switch (i) {
            case 2: // 电流
                gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]];
                break;
            case 3: // 电池温度
            case 6: // 车内温度
                gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]];
                break;
            case 4: // 电池电压
            case 5: // 电瓶电压
                gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]];
                break;
            case 7: { // 档位
                NSInteger g = [val integerValue];
                gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
                break;
            }
            default: // 百分比
                gValues[i].text = [NSString stringWithFormat:@"%@%%", val];
                break;
        }
    }

    // 刷新时间 = 系统当前时间
    if (gTimeLabel && gDateFmt) {
        gTimeLabel.text = [NSString stringWithFormat:@"更新: %@", [gDateFmt stringFromDate:[NSDate date]]];
    }

    // 锁定图标
    if (gLockIcon) {
        gLockIcon.text = gLocked ? @"🔒" : @"🔓";
    }
}

// ============================================================
// MARK: - 保存/加载位置
// ============================================================

static void BJSaveState(void) {
    if (!gHUD) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:[NSValue valueWithCGRect:gHUD.frame] forKey:kFrameKey];
    [ud setFloat:gScale forKey:kScaleKey];
    [ud setBool:gLocked forKey:kLockKey];
    [ud synchronize];
}

static void BJLoadState(void) {
    if (!gHUD) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    id frameVal = [ud objectForKey:kFrameKey];
    if (frameVal && [frameVal isKindOfClass:[NSValue class]]) {
        gHUD.frame = [frameVal CGRectValue];
    }
    CGFloat s = [ud floatForKey:kScaleKey];
    if (s > 0.3 && s < 3.0) gScale = s;
    gHUD.transform = CGAffineTransformMakeScale(gScale, gScale);
    gLocked = [ud boolForKey:kLockKey];
}

// ============================================================
// MARK: - 创建 HUD
// ============================================================

static void BJCreateHUD(void) {
    if (gHUD) return;

    gDateFmt = [[NSDateFormatter alloc] init];
    gDateFmt.dateFormat = @"HH:mm:ss";

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;
    CGFloat baseW = 170;
    CGFloat baseH = 220;

    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - baseW - 10, 80, baseW, baseH)];
    gHUD.backgroundColor = [[UIColor colorWithWhite:1.0 alpha:0.82] colorWithAlphaComponent:0.82];
    gHUD.layer.cornerRadius = 14;
    gHUD.layer.shadowColor = [UIColor blackColor].CGColor;
    gHUD.layer.shadowOffset = CGSizeMake(0, 2);
    gHUD.layer.shadowRadius = 10;
    gHUD.layer.shadowOpacity = 0.2;

    CGFloat y = 6;
    CGFloat rowH = 22;
    CGFloat leftColW = 80;
    CGFloat rightStart = 85;

    // 锁定图标（右上角）
    gLockIcon = [[UILabel alloc] initWithFrame:CGRectMake(baseW - 22, 4, 18, 18)];
    gLockIcon.text = @"🔓";
    gLockIcon.font = [UIFont systemFontOfSize:11];
    [gHUD addSubview:gLockIcon];

    // 8 行数据定义
    struct { NSString *sfIcon; NSString *label; CGFloat x; CGFloat y; } rows[] = {
        {@"heart.fill",         @"电池健康", 6,  y},
        {@"bolt.fill",          @"电池电量", 6,  y + rowH},
        {@"waveform",           @"电池电流", 6,  y + rowH*2},
        {@"thermometer",        @"电池温度", 6,  y + rowH*3},
        {@"bolt.circle",        @"电池电压", rightStart, y},
        {@"car.side",           @"电瓶电压", rightStart, y + rowH},
        {@"thermometer.sun",    @"车内温度", rightStart, y + rowH*2},
        {@"gearshape",          @"档位",     rightStart, y + rowH*3},
    };

    for (int i = 0; i < 8; i++) {
        // SF Symbol 图标
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(rows[i].x, rows[i].y + 3, 12, 12)];
        UIImage *img = [UIImage systemImageNamed:rows[i].sfIcon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:9 weight:UIFontWeightMedium]];
            icon.tintColor = [UIColor systemBlueColor];
        }
        [gHUD addSubview:icon];

        // 标签
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 15, rows[i].y + 1, 48, rowH)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:8];
        lbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.55];
        [gHUD addSubview:lbl];

        // 数值
        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 63, rows[i].y + 1, leftColW - 63, rowH)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:10 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor blackColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [gHUD addSubview:gValues[i]];
    }

    // 分割线
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(6, y + rowH*4 + 3, baseW - 12, 0.5)];
    sep.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.1];
    [gHUD addSubview:sep];

    // 刷新时间
    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(6, y + rowH*4 + 6, baseW - 12, 14)];
    gTimeLabel.font = [UIFont systemFontOfSize:9];
    gTimeLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    gTimeLabel.text = @"更新: --:--:--";
    [gHUD addSubview:gTimeLabel];

    // 手势
    BJGestureHandler *handler = [BJGestureHandler shared];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:handler action:@selector(handlePan:)];
    [gHUD addGestureRecognizer:pan];

    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:handler action:@selector(handlePinch:)];
    [gHUD addGestureRecognizer:pinch];

    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:handler action:@selector(handleDoubleTap:)];
    doubleTap.numberOfTapsRequired = 2;
    [gHUD addGestureRecognizer:doubleTap];

    // 拖拽和缩放需要同时识别
    [pan requireGestureRecognizerToFail:doubleTap];

    // 读取保存的状态
    BJLoadState();

    // 添加到 keyWindow
    UIWindow *kw = nil;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { kw = w; break; }
    }
    if (kw) [kw addSubview:gHUD];

    // 初始加载
    BJRefreshHUD();
}

// ============================================================
// MARK: - 启动轮询（备份）
// ============================================================

static void BJStartPolling(void) {
    if (gPollTimer) return;
    gPollTimer = [NSTimer scheduledTimerWithTimeInterval:10.0
        target:[BJGestureHandler shared]
        selector:@selector(onPoll)
        userInfo:nil
        repeats:YES];
}

// ============================================================
// MARK: - 手势处理
// ============================================================

@implementation BJGestureHandler

+ (instancetype)shared {
    static BJGestureHandler *o;
    static dispatch_once_t t;
    dispatch_once(&t, ^{ o = [BJGestureHandler new]; });
    return o;
}

- (void)onPoll {
    dispatch_async(dispatch_get_main_queue(), ^{
        BJRefreshHUD();
    });
}

- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (gLocked) return;
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGSize size = g.view.bounds.size;
        CGFloat w = size.width * gScale;
        CGFloat h = size.height * gScale;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width;
        CGFloat sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(
            MAX(w/2, MIN(loc.x, sx - w/2)),
            MAX(44 + h/2, MIN(loc.y, sy - h/2))
        );
    }
    if (g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) {
        BJSaveState();
    }
}

- (void)handlePinch:(UIPinchGestureRecognizer *)g {
    if (gLocked) return;
    if (g.state == UIGestureRecognizerStateChanged) {
        gScale *= g.scale;
        gScale = MAX(0.5, MIN(gScale, 2.5));
        g.view.transform = CGAffineTransformMakeScale(gScale, gScale);
        g.scale = 1.0;
    }
    if (g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) {
        BJSaveState();
    }
}

- (void)handleDoubleTap:(UITapGestureRecognizer *)g {
    gLocked = !gLocked;
    if (gLockIcon) {
        gLockIcon.text = gLocked ? @"🔒" : @"🔓";
    }
    BJSaveState();
    // 震动反馈
    UIImpactFeedbackGenerator *fb = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
    [fb impactOccurred];
}

@end

// ============================================================
// MARK: - Hooks
// ============================================================

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.sgmw.baojunplus"]) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
            BJStartPolling();
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.sgmw.baojunplus"]) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
            BJStartPolling();
        });
}
%end

// NSUserDefaults 写入时实时刷新
%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.sgmw.baojunplus"]) return;
    if ([defaultName containsString:@"car_status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            BJRefreshHUD();
        });
    }
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] v1.0 loaded bid=%@", [NSBundle mainBundle].bundleIdentifier);
    }
}
