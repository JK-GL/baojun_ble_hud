#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

static UIView *gHUD = nil;
static UIView *gCollapsed = nil;
static UIView *gExpanded = nil;
static UILabel *gValues[9] = {nil};
static UILabel *gTimeLabel = nil;
static UILabel *gKwhLabel = nil;
static NSDateFormatter *gDateFmt = nil;
static NSTimer *gPollTimer = nil;
static BOOL gIsTargetApp = NO;
static BOOL gIsExpanded = NO;

static BOOL BJCheckTarget(void) {
    if (gIsTargetApp) return YES;
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    gIsTargetApp = [bid isEqualToString:@"com.sgmw.baojunplus"] ||
                   [bid isEqualToString:@"com.cloudy.LingLingBang"];
    return gIsTargetApp;
}

static NSDictionary *BJReadCarStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) {
            sd = val;
        } else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) {
                id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil];
                if ([p isKindOfClass:[NSDictionary class]]) sd = p;
            }
        }
        if (sd && sd[@"leftBatteryPower"]) return sd;
    }
    return nil;
}

static void BJRefreshHUD(void) {
    if (!gHUD) return;
    NSDictionary *sd = BJReadCarStatus();
    if (!sd) return;

    NSString *keys[] = {
        @"batSOH", @"current", @"batAvgTemp",
        @"voltage", @"lowBatVol", @"interiorTemperature",
        @"keyStatus", @"strWhAng", @"autoGearStatus"
    };

    for (int i = 0; i < 9; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        switch (i) {
            case 1: gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]]; break;
            case 2: case 5: gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]]; break;
            case 3: case 4: gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]]; break;
            case 6: {
                NSInteger k = [val integerValue];
                gValues[i].text = (k==0)?@"已锁":(k==2)?@"在车":(k==1)?@"解锁":[NSString stringWithFormat:@"%ld",(long)k];
                break;
            }
            case 7: gValues[i].text = [NSString stringWithFormat:@"%.1f°", [val doubleValue]]; break;
            case 8: {
                NSInteger g = [val integerValue];
                gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
                break;
            }
            default: gValues[i].text = [NSString stringWithFormat:@"%@%%", val]; break;
        }
    }

    // Collapsed pill: show kWh with SF Symbol
    if (gKwhLabel) {
        id kwh = sd[@"leftBatteryPower"];
        if (kwh) {
            UIImage *boltImg = [UIImage systemImageNamed:@"bolt.fill"];
            if (boltImg) {
                NSTextAttachment *att = [[NSTextAttachment alloc] init];
                att.image = [boltImg imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:11 weight:UIFontWeightMedium]];
                att.bounds = CGRectMake(0, -2, 12, 14);
                NSString *numStr = [NSString stringWithFormat:@" %.1fkWh", [kwh doubleValue]];
                NSMutableAttributedString *as = [[NSMutableAttributedString alloc] initWithString:numStr attributes:@{NSFontAttributeName: [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightSemibold], NSForegroundColorAttributeName: [UIColor whiteColor]}];
                [as insertAttributedString:[NSAttributedString attributedStringWithAttachment:att] atIndex:0];
                gKwhLabel.attributedText = as;
            } else {
                gKwhLabel.text = [NSString stringWithFormat:@"⚡ %.1fkWh", [kwh doubleValue]];
            }
        }
    }

    if (gTimeLabel && gDateFmt) {
        gTimeLabel.text = [NSString stringWithFormat:@"更新: %@", [gDateFmt stringFromDate:[NSDate date]]];
    }
}

static void BJToggleHUD(void);

@interface UIView (BJHUDPan)
- (void)bj_handlePan:(UIPanGestureRecognizer *)g;
- (void)bj_handleTap:(UITapGestureRecognizer *)g;
@end

@implementation UIView (BJHUDPan)
- (void)bj_handlePan:(UIPanGestureRecognizer *)g {
    CGPoint pt = [g translationInView:self.superview];
    self.center = CGPointMake(self.center.x + pt.x, self.center.y + pt.y);
    [g setTranslation:CGPointZero inView:self.superview];
}
- (void)bj_handleTap:(UITapGestureRecognizer *)g {
    BJToggleHUD();
}
@end

static void BJScheduleTimer(void) {
    if (gPollTimer) return;
    gPollTimer = [NSTimer scheduledTimerWithTimeInterval:10.0 repeats:YES block:^(NSTimer *t) {
        BJRefreshHUD();
    }];
}

static void BJCreateHUD(void) {
    if (gHUD) return;

    gDateFmt = [[NSDateFormatter alloc] init];
    gDateFmt.dateFormat = @"HH:mm:ss";

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;

    // --- Main container ---
    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - 110, 80, 100, 36)];
    gHUD.backgroundColor = [UIColor clearColor];
    gHUD.clipsToBounds = NO;

    // --- Collapsed pill ---
    gCollapsed = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 36)];
    gCollapsed.backgroundColor = [UIColor colorWithWhite:0.15 alpha:0.75];
    gCollapsed.layer.cornerRadius = 18;
    gCollapsed.clipsToBounds = YES;

    gKwhLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 36)];
    gKwhLabel.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightSemibold];
    gKwhLabel.textColor = [UIColor whiteColor];
    gKwhLabel.textAlignment = NSTextAlignmentCenter;
    // Default text with SF Symbol
    UIImage *boltImg = [UIImage systemImageNamed:@"bolt.fill"];
    if (boltImg) {
        NSTextAttachment *att = [[NSTextAttachment alloc] init];
        att.image = [boltImg imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:11 weight:UIFontWeightMedium]];
        att.bounds = CGRectMake(0, -2, 12, 14);
        NSMutableAttributedString *as = [[NSMutableAttributedString alloc] initWithString:@" --kWh" attributes:@{NSFontAttributeName: [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightSemibold]}];
        [as insertAttributedString:[NSAttributedString attributedStringWithAttachment:att] atIndex:0];
        gKwhLabel.attributedText = as;
    } else {
        gKwhLabel.text = @"⚡ --kWh";
    }
    [gCollapsed addSubview:gKwhLabel];

    UITapGestureRecognizer *tapCollapse = [[UITapGestureRecognizer alloc] initWithTarget:gCollapsed action:@selector(bj_handleTap:)];
    [gCollapsed addGestureRecognizer:tapCollapse];

    [gHUD addSubview:gCollapsed];

    // --- Expanded card (dark blur) ---
    CGFloat cardW = 155;
    CGFloat headerH = 24;
    CGFloat rowH = 20;
    CGFloat footerH = 16;
    CGFloat cardH = headerH + 9 * rowH + footerH + 6;

    gExpanded = [[UIView alloc] initWithFrame:CGRectMake(0, 0, cardW, cardH)];

    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView *blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
    blurView.frame = gExpanded.bounds;
    blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    blurView.layer.cornerRadius = 14;
    blurView.clipsToBounds = YES;
    [gExpanded addSubview:blurView];

    UIView *contentView = blurView.contentView;

    // Header: SF Symbol bolt.fill + kWh
    UIImageView *hdrIcon = [[UIImageView alloc] initWithFrame:CGRectMake(10, 4, 14, 16)];
    UIImage *hdrImg = [UIImage systemImageNamed:@"bolt.fill"];
    if (hdrImg) {
        hdrIcon.image = [hdrImg imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:10 weight:UIFontWeightBold]];
        hdrIcon.tintColor = [UIColor systemGreenColor];
    }
    hdrIcon.tag = 9002;
    [contentView addSubview:hdrIcon];

    UILabel *hdr = [[UILabel alloc] initWithFrame:CGRectMake(26, 4, cardW - 36, 16)];
    hdr.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightBold];
    hdr.textColor = [UIColor systemGreenColor];
    hdr.textAlignment = NSTextAlignmentLeft;
    hdr.tag = 9001;
    [contentView addSubview:hdr];

    UIView *sep1 = [[UIView alloc] initWithFrame:CGRectMake(6, headerH, cardW - 12, 0.5)];
    sep1.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.15];
    [contentView addSubview:sep1];

    // Data rows (9 items, no 电量 row)
    struct { NSString *icon; NSString *label; UIColor *color; } rows[] = {
        {@"heart.fill",      @"健康",   [UIColor systemPinkColor]},
        {@"waveform",        @"电流",   [UIColor systemTealColor]},
        {@"thermometer",     @"电池温", [UIColor systemOrangeColor]},
        {@"bolt.circle",     @"电池压", [UIColor systemYellowColor]},
        {@"car",             @"电瓶压", [UIColor systemBlueColor]},
        {@"sun.max",         @"车内温", [UIColor systemRedColor]},
        {@"key.fill",        @"钥匙",   [UIColor systemCyanColor]},
        {@"scope",           @"转角",   [UIColor systemIndigoColor]},
        {@"gearshape",       @"档位",   [UIColor systemPurpleColor]},
    };

    for (int i = 0; i < 9; i++) {
        CGFloat y = headerH + 2 + i * rowH;

        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(6, y + 3, 11, 11)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:7 weight:UIFontWeightMedium]];
            icon.tintColor = rows[i].color;
        }
        [contentView addSubview:icon];

        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(20, y + 1, 36, 16)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:8];
        lbl.textColor = [UIColor colorWithWhite:1.0 alpha:0.6];
        [contentView addSubview:lbl];

        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(58, y + 1, cardW - 66, 16)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:9 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor whiteColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [contentView addSubview:gValues[i]];
    }

    // Footer
    UIView *sep2 = [[UIView alloc] initWithFrame:CGRectMake(6, headerH + 9 * rowH + 2, cardW - 12, 0.5)];
    sep2.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.15];
    [contentView addSubview:sep2];

    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(6, headerH + 9 * rowH + 4, cardW - 12, footerH)];
    gTimeLabel.font = [UIFont systemFontOfSize:8];
    gTimeLabel.textColor = [UIColor colorWithWhite:1.0 alpha:0.4];
    gTimeLabel.text = @"更新: --:--:--";
    [contentView addSubview:gTimeLabel];

    gExpanded.hidden = YES;
    [gHUD addSubview:gExpanded];

    // Pan gesture on expanded
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:gHUD action:@selector(bj_handlePan:)];
    [gExpanded addGestureRecognizer:pan];

    // Tap anywhere on expanded to collapse
    UITapGestureRecognizer *tapExpand = [[UITapGestureRecognizer alloc] initWithTarget:gHUD action:@selector(bj_handleTap:)];
    [gExpanded addGestureRecognizer:tapExpand];

    // Add to keyWindow
    UIWindow *kw = nil;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { kw = w; break; }
    }
    if (kw) [kw addSubview:gHUD];

    BJRefreshHUD();
}

static void BJToggleHUD(void) {
    if (!gHUD || !gCollapsed || !gExpanded) return;
    gIsExpanded = !gIsExpanded;

    if (gIsExpanded) {
        CGFloat cardW = 155;
        CGFloat headerH = 24;
        CGFloat rowH = 20;
        CGFloat footerH = 16;
        CGFloat cardH = headerH + 9 * rowH + footerH + 6;

        gCollapsed.hidden = YES;
        gExpanded.hidden = NO;
        gHUD.frame = CGRectMake(gHUD.frame.origin.x, gHUD.frame.origin.y, cardW, cardH);

        // Update header with kWh
        NSDictionary *sd = BJReadCarStatus();
        if (sd) {
            id kwh = sd[@"leftBatteryPower"];
            UILabel *hdr = (UILabel *)[gExpanded viewWithTag:9001];
            if (hdr && kwh) hdr.text = [NSString stringWithFormat:@"%.1fkWh", [kwh doubleValue]];
        }
        BJRefreshHUD();
    } else {
        gCollapsed.hidden = NO;
        gExpanded.hidden = YES;
        gHUD.frame = CGRectMake(gHUD.frame.origin.x, gHUD.frame.origin.y, 100, 36);
        BJRefreshHUD();
    }
}

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJCheckTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
            BJScheduleTimer();
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJCheckTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
        });
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] v4.0 loaded %@", [NSBundle mainBundle].bundleIdentifier);
    }
}
