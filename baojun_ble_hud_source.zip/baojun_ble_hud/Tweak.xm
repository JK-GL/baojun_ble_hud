#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <objc/runtime.h>

// ============================================================
// MARK: - 前向声明
// ============================================================

@interface BJPanHandler : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
@end

@interface BJTick : NSObject
+ (instancetype)shared;
- (void)onTick;
@end

// ============================================================
// MARK: - 全局变量
// ============================================================

static UIView *gCard = nil;
static UILabel *gValues[8];
static UILabel *gTimeLabel = nil;
static NSDateFormatter *gFmt = nil;
static BOOL gTimerStarted = NO;

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

// ============================================================
// MARK: - 读取车辆状态
// ============================================================

static NSDictionary *BJReadStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) sd = val;
        else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) { id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil]; if ([p isKindOfClass:[NSDictionary class]]) sd = p; }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

// ============================================================
// MARK: - 更新卡片数值
// ============================================================

static void BJUpdateCard(void) {
    if (!gCard) return;
    NSDictionary *sd = BJReadStatus();
    if (!sd) return;

    NSString *keys[] = {@"batSOH", @"batterySoc", @"current", @"batAvgTemp", @"voltage", @"lowBatVol", @"interiorTemperature", @"autoGearStatus"};

    for (int i = 0; i < 8; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        if (i == 2) gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]];
        else if (i == 3 || i == 6) gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]];
        else if (i == 4 || i == 5) gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]];
        else if (i == 7) {
            NSInteger g = [val integerValue];
            gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
        }
        else gValues[i].text = [NSString stringWithFormat:@"%@%%", val];
    }

    if (gTimeLabel) {
        NSString *t = sd[@"collectTime"] ?: @"--";
        if ([t length] >= 19) t = [t substringFromIndex:11];
        gTimeLabel.text = [NSString stringWithFormat:@"数据更新: %@", t];
    }
}

// ============================================================
// MARK: - 创建嵌入式卡片 (仿官方模块风格)
// ============================================================

static void BJEnsureCard(void) {
    if (gCard) return;

    gFmt = [[NSDateFormatter alloc] init];
    gFmt.dateFormat = @"HH:mm:ss";

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;
    CGFloat sh = [UIScreen mainScreen].bounds.size.height;

    // 卡片尺寸 - 仿官方"剩余电量"和"空调"卡片的大小
    // 官方卡片位置大约在屏幕 55%~70% 处，左右各一张
    // 我们做一个全宽卡片放在它们下方

    CGFloat cardW = sw - 32; // 左右各留16
    CGFloat cardH = 130;     // 和官方卡片差不多高
    CGFloat cardX = 16;
    CGFloat cardY = sh * 0.62; // 放在官方卡片下方区域

    // 卡片背景 - 仿官方白色圆角卡片
    gCard = [[UIView alloc] initWithFrame:CGRectMake(cardX, cardY, cardW, cardH)];
    gCard.backgroundColor = [UIColor whiteColor];
    gCard.layer.cornerRadius = 12;
    gCard.layer.shadowColor = [UIColor blackColor].CGColor;
    gCard.layer.shadowOffset = CGSizeMake(0, 1);
    gCard.layer.shadowRadius = 8;
    gCard.layer.shadowOpacity = 0.06;
    gCard.tag = 9999;

    // 标题
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(16, 10, 200, 16)];
    title.text = @"车辆状态";
    title.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    title.textColor = [UIColor blackColor];
    [gCard addSubview:title];

    // 分割线
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(16, 30, cardW - 32, 0.5)];
    sep.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.06];
    [gCard addSubview:sep];

    // 两列布局 - 和官方卡片风格一致
    CGFloat startY = 36;
    CGFloat rowH = 18;
    CGFloat colW = (cardW - 32) / 2;

    struct { NSString *icon; NSString *label; int tag; CGFloat x; CGFloat y; } rows[] = {
        {@"heart.fill",         @"电池健康", 0, 16,  startY},
        {@"bolt.fill",          @"电池电量", 1, 16,  startY + rowH},
        {@"waveform.path.ecg",  @"电池电流", 2, 16,  startY + rowH*2},
        {@"thermometer.medium", @"电池温度", 3, 16,  startY + rowH*3},
        {@"bolt.circle.fill",   @"电池电压", 4, colW+16, startY},
        {@"car.2.fill",         @"电瓶电压", 5, colW+16, startY + rowH},
        {@"thermometer.medium", @"车内温度", 6, colW+16, startY + rowH*2},
        {@"gearshape",          @"档位",     7, colW+16, startY + rowH*3},
    };

    for (int i = 0; i < 8; i++) {
        // SF Symbol 图标
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(rows[i].x, rows[i].y + 2, 12, 12)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:9 weight:UIFontWeightRegular]];
            icon.tintColor = [UIColor systemGrayColor];
        }
        [gCard addSubview:icon];

        // 标签
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 16, rows[i].y, 56, rowH)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:10];
        lbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.45];
        [gCard addSubview:lbl];

        // 数值
        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 72, rows[i].y, colW - 88, rowH)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor blackColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [gCard addSubview:gValues[i]];
    }

    // 底部分割线
    UIView *sep2 = [[UIView alloc] initWithFrame:CGRectMake(16, startY + rowH*4 + 4, cardW - 32, 0.5)];
    sep2.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.06];
    [gCard addSubview:sep2];

    // 数据更新时间
    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, startY + rowH*4 + 8, cardW - 32, 12)];
    gTimeLabel.font = [UIFont systemFontOfSize:9];
    gTimeLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    gTimeLabel.text = @"数据更新: --";
    [gCard addSubview:gTimeLabel];

    NSLog(@"[BJBLE] 卡片已创建");
}

// ============================================================
// MARK: - 注入到 keyWindow
// ============================================================

static void BJInjectToWindow(void) {
    BJEnsureCard();
    if (!gCard) return;

    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop

    if (!keyWindow) return;

    // 已注入则跳过
    if ([keyWindow viewWithTag:9999]) {
        BJUpdateCard();
        return;
    }

    [keyWindow addSubview:gCard];
    BJUpdateCard();

    // 定时刷新
    if (!gTimerStarted) {
        gTimerStarted = YES;
        [[NSRunLoop currentRunLoop] addTimer:
            [NSTimer scheduledTimerWithTimeInterval:3.0
                target:[BJTick shared] selector:@selector(onTick)
                userInfo:nil repeats:YES]
            forMode:NSRunLoopCommonModes];
    }

    NSLog(@"[BJBLE] 卡片已注入到 keyWindow");
}

// ============================================================
// MARK: - 定时器 + 拖拽
// ============================================================

@implementation BJTick
+ (instancetype)shared { static BJTick *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJTick new]; }); return o; }
- (void)onTick { dispatch_async(dispatch_get_main_queue(), ^{ BJUpdateCard(); }); }
@end

@implementation BJPanHandler
+ (instancetype)shared { static BJPanHandler *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJPanHandler new]; }); return o; }
- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGFloat w = g.view.bounds.size.width, h = g.view.bounds.size.height;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width, sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(MAX(w/2, MIN(loc.x, sx-w/2)), MAX(40+h/2, MIN(loc.y, sy-h-40)));
    }
}
@end

// ============================================================
// MARK: - Hooks
// ============================================================

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJIsTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{ BJInjectToWindow(); });
}
%end

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJIsTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{ BJInjectToWindow(); });
}
%end

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ BJUpdateCard(); });
    }
}
%end

// ============================================================
// MARK: - 入口
// ============================================================

%ctor {
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] ====== 宝骏云海 HUD 已加载 (嵌入模式) ======");
}
