#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BJGestureHandler : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
- (void)handlePinch:(UIPinchGestureRecognizer *)g;
- (void)handleDoubleTap:(UITapGestureRecognizer *)g;
@end

static UIView *gHUD = nil;
static UILabel *gValues[8] = {nil};
static UILabel *gTimeLabel = nil;
static UILabel *gLockIcon = nil;
static BOOL gLocked = NO;
static CGFloat gScale = 1.0;
static NSDateFormatter *gDateFmt = nil;
static NSTimer *gPollTimer = nil;
static BOOL gIsTargetApp = NO;

static NSString *const kFrameKey = @"BJHUD_Frame_v2";
static NSString *const kScaleKey = @"BJHUD_Scale_v2";
static NSString *const kLockKey  = @"BJHUD_Lock_v2";

// 检查是否是目标 App
static BOOL BJCheckTarget(void) {
    if (gIsTargetApp) return YES;
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    gIsTargetApp = [bid isEqualToString:@"com.sgmw.baojunplus"] ||
                   [bid isEqualToString:@"com.cloudy.LingLingBang"];
    return gIsTargetApp;
}

// ============================================================
// MARK: - 读取车辆状态
// ============================================================

static NSDictionary *BJReadCarStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) {
            sd = val;
        } else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) {
                id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil];
                if ([p isKindOfClass:[NSDictionary class]]) sd = p;
            }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

// ============================================================
// MARK: - 刷新 HUD
// ============================================================

static void BJRefreshHUD(void) {
    if (!gHUD) return;
    NSDictionary *sd = BJReadCarStatus();
    if (!sd) return;

    NSString *keys[] = {
        @"batSOH",              // 0: 电池健康
        @"batterySoc",          // 1: 电池电量
        @"current",             // 2: 电池电流
        @"batAvgTemp",          // 3: 电池温度
        @"voltage",             // 4: 电池电压
        @"lowBatVol",           // 5: 电瓶电压
        @"interiorTemperature", // 6: 车内温度
        @"autoGearStatus"       // 7: 档位
    };

    for (int i = 0; i < 8; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        switch (i) {
            case 2:
                gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]];
                break;
            case 3: case 6:
                gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]];
                break;
            case 4: case 5:
                gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]];
                break;
            case 7: {
                NSInteger g = [val integerValue];
                gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
                break;
            }
            default:
                gValues[i].text = [NSString stringWithFormat:@"%@%%", val];
                break;
        }
    }

    if (gTimeLabel && gDateFmt) {
        gTimeLabel.text = [NSString stringWithFormat:@"更新: %@", [gDateFmt stringFromDate:[NSDate date]]];
    }
    if (gLockIcon) {
        gLockIcon.text = gLocked ? @"🔒" : @"🔓";
    }
}

// ============================================================
// MARK: - 保存/加载状态
// ============================================================

static void BJSaveState(void) {
    if (!gHUD) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:[NSValue valueWithCGRect:gHUD.frame] forKey:kFrameKey];
    [ud setFloat:gScale forKey:kScaleKey];
    [ud setBool:gLocked forKey:kLockKey];
    [ud synchronize];
}

static void BJLoadState(void) {
    if (!gHUD) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    id fv = [ud objectForKey:kFrameKey];
    if (fv && [fv isKindOfClass:[NSValue class]]) {
        gHUD.frame = [fv CGRectValue];
    }
    CGFloat s = [ud floatForKey:kScaleKey];
    if (s > 0.3 && s < 3.0) gScale = s;
    gHUD.transform = CGAffineTransformMakeScale(gScale, gScale);
    gLocked = [ud boolForKey:kLockKey];
}

// ============================================================
// MARK: - 创建 HUD（竖排）
// ============================================================

static void BJCreateHUD(void) {
    if (gHUD) return;

    gDateFmt = [[NSDateFormatter alloc] init];
    gDateFmt.dateFormat = @"HH:mm:ss";

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;
    CGFloat baseW = 150;
    CGFloat baseH = 280;

    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - baseW - 10, 80, baseW, baseH)];
    gHUD.backgroundColor = [[UIColor colorWithWhite:1.0 alpha:0.85] colorWithAlphaComponent:0.85];
    gHUD.layer.cornerRadius = 14;
    gHUD.layer.shadowColor = [UIColor blackColor].CGColor;
    gHUD.layer.shadowOffset = CGSizeMake(0, 2);
    gHUD.layer.shadowRadius = 10;
    gHUD.layer.shadowOpacity = 0.15;

    // 锁定图标
    gLockIcon = [[UILabel alloc] initWithFrame:CGRectMake(baseW - 22, 4, 18, 18)];
    gLockIcon.text = @"🔓";
    gLockIcon.font = [UIFont systemFontOfSize:11];
    [gHUD addSubview:gLockIcon];

    // 竖排布局 - 每行一个数据
    CGFloat startY = 6;
    CGFloat rowH = 28;

    // SF Symbols（iOS 15 兼容）
    struct { NSString *icon; NSString *label; } rows[] = {
        {@"heart.fill",      @"电池健康"},
        {@"bolt.fill",       @"电池电量"},
        {@"waveform",        @"电池电流"},
        {@"thermometer",     @"电池温度"},
        {@"bolt.circle",     @"电池电压"},
        {@"car",             @"电瓶电压"},
        {@"sun.max",         @"车内温度"},
        {@"gearshape",       @"档位"},
    };

    for (int i = 0; i < 8; i++) {
        CGFloat y = startY + i * rowH;

        // 图标
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(10, y + 5, 14, 14)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:10 weight:UIFontWeightMedium]];
            icon.tintColor = [UIColor systemBlueColor];
        }
        [gHUD addSubview:icon];

        // 标签
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(30, y + 3, 50, 18)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:9];
        lbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
        [gHUD addSubview:lbl];

        // 数值
        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(85, y + 3, 55, 18)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor blackColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [gHUD addSubview:gValues[i]];
    }

    // 分割线
    CGFloat sepY = startY + 8 * rowH + 2;
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(10, sepY, baseW - 20, 0.5)];
    sep.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.1];
    [gHUD addSubview:sep];

    // 刷新时间
    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, sepY + 4, baseW - 20, 14)];
    gTimeLabel.font = [UIFont systemFontOfSize:9];
    gTimeLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    gTimeLabel.text = @"更新: --:--:--";
    [gHUD addSubview:gTimeLabel];

    // 手势
    BJGestureHandler *handler = [BJGestureHandler shared];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:handler action:@selector(handlePan:)];
    [gHUD addGestureRecognizer:pan];

    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:handler action:@selector(handlePinch:)];
    [gHUD addGestureRecognizer:pinch];

    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:handler action:@selector(handleDoubleTap:)];
    doubleTap.numberOfTapsRequired = 2;
    [gHUD addGestureRecognizer:doubleTap];

    [pan requireGestureRecognizerToFail:doubleTap];

    BJLoadState();

    UIWindow *kw = nil;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { kw = w; break; }
    }
    if (kw) [kw addSubview:gHUD];

    BJRefreshHUD();
}

// ============================================================
// MARK: - 手势处理
// ============================================================

@implementation BJGestureHandler

+ (instancetype)shared {
    static BJGestureHandler *o;
    static dispatch_once_t t;
    dispatch_once(&t, ^{ o = [BJGestureHandler new]; });
    return o;
}

- (void)onPoll {
    dispatch_async(dispatch_get_main_queue(), ^{ BJRefreshHUD(); });
}

- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (gLocked) return;
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGSize size = g.view.bounds.size;
        CGFloat w = size.width * gScale;
        CGFloat h = size.height * gScale;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width;
        CGFloat sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(
            MAX(w/2, MIN(loc.x, sx - w/2)),
            MAX(44 + h/2, MIN(loc.y, sy - h/2))
        );
    }
    if (g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) {
        BJSaveState();
    }
}

- (void)handlePinch:(UIPinchGestureRecognizer *)g {
    if (gLocked) return;
    if (g.state == UIGestureRecognizerStateChanged) {
        gScale *= g.scale;
        gScale = MAX(0.5, MIN(gScale, 2.5));
        g.view.transform = CGAffineTransformMakeScale(gScale, gScale);
        g.scale = 1.0;
    }
    if (g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) {
        BJSaveState();
    }
}

- (void)handleDoubleTap:(UITapGestureRecognizer *)g {
    gLocked = !gLocked;
    if (gLockIcon) gLockIcon.text = gLocked ? @"🔒" : @"🔓";
    BJSaveState();
    UIImpactFeedbackGenerator *fb = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
    [fb impactOccurred];
}

@end

// ============================================================
// MARK: - Hooks
// ============================================================

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJCheckTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
            if (!gPollTimer) {
                gPollTimer = [NSTimer scheduledTimerWithTimeInterval:10.0
                    target:[BJGestureHandler shared]
                    selector:@selector(onPoll)
                    userInfo:nil repeats:YES];
            }
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJCheckTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
            if (!gPollTimer) {
                gPollTimer = [NSTimer scheduledTimerWithTimeInterval:10.0
                    target:[BJGestureHandler shared]
                    selector:@selector(onPoll)
                    userInfo:nil repeats:YES];
            }
        });
}
%end

// 只在目标 App 中 Hook NSUserDefaults
%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!gIsTargetApp) return;
    if ([defaultName containsString:@"car_status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ BJRefreshHUD(); });
    }
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] v2.0 loaded %@", [NSBundle mainBundle].bundleIdentifier);
    }
}
