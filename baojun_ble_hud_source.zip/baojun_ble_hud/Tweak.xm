#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BJPanHelper : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
- (void)handlePinch:(UIPinchGestureRecognizer *)g;
- (void)handleDoubleTap:(UITapGestureRecognizer *)g;
@end

static UIView *gHUD = nil;
static UILabel *gValues[8];
static UILabel *gTimeLabel = nil;
static UILabel *gLockIcon = nil;
static BOOL gLocked = NO;
static CGFloat gScale = 1.0;

static NSString *const kHUDFrameKey = @"BJHUD_Frame";
static NSString *const kHUDScaleKey = @"BJHUD_Scale";
static NSString *const kHUDLockedKey = @"BJHUD_Locked";

// ============================================================
// MARK: - 工具函数
// ============================================================

static BOOL BJIsTarget(void) {
    return [[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.sgmw.baojunplus"];
}

static NSDictionary *BJReadStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) sd = val;
        else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) { id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil]; if ([p isKindOfClass:[NSDictionary class]]) sd = p; }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

// ============================================================
// MARK: - 保存/读取位置
// ============================================================

static void BJSaveFrame(void) {
    if (!gHUD) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSValue *frameValue = [NSValue valueWithCGRect:gHUD.frame];
    [ud setObject:frameValue forKey:kHUDFrameKey];
    [ud setFloat:gScale forKey:kHUDScaleKey];
    [ud setBool:gLocked forKey:kHUDLockedKey];
    [ud synchronize];
}

static void BJLoadFrame(void) {
    if (!gHUD) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    id frameData = [ud objectForKey:kHUDFrameKey];
    if (frameData && [frameData isKindOfClass:[NSValue class]]) {
        gHUD.frame = [frameData CGRectValue];
        gScale = [ud floatForKey:kHUDScaleKey];
        if (gScale <= 0) gScale = 1.0;
        gHUD.transform = CGAffineTransformMakeScale(gScale, gScale);
        gLocked = [ud boolForKey:kHUDLockedKey];
    }
}

// ============================================================
// MARK: - 刷新 HUD 数值
// ============================================================

static void BJRefreshHUD(void) {
    if (!gHUD) return;
    NSDictionary *sd = BJReadStatus();
    if (!sd) return;

    NSString *keys[] = {@"batSOH", @"batterySoc", @"current", @"batAvgTemp", @"voltage", @"lowBatVol", @"interiorTemperature", @"autoGearStatus"};
    for (int i = 0; i < 8; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        if (i == 2) gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]];
        else if (i == 3 || i == 6) gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]];
        else if (i == 4 || i == 5) gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]];
        else if (i == 7) {
            NSInteger g = [val integerValue];
            gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
        }
        else gValues[i].text = [NSString stringWithFormat:@"%@%%", val];
    }

    if (gTimeLabel) {
        NSString *t = sd[@"collectTime"] ?: @"--";
        if ([t length] >= 19) t = [t substringFromIndex:11];
        gTimeLabel.text = [NSString stringWithFormat:@"更新: %@", t];
    }

    if (gLockIcon) {
        gLockIcon.text = gLocked ? @"🔒" : @"🔓";
    }
}

// ============================================================
// MARK: - 显示 HUD
// ============================================================

static void BJShowHUD(void) {
    if (gHUD) return;

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;

    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - 180, 80, 170, 200)];
    gHUD.backgroundColor = [[UIColor colorWithWhite:1.0 alpha:0.80] colorWithAlphaComponent:0.80];
    gHUD.layer.cornerRadius = 14;
    gHUD.layer.shadowColor = [UIColor blackColor].CGColor;
    gHUD.layer.shadowOffset = CGSizeMake(0, 2);
    gHUD.layer.shadowRadius = 8;
    gHUD.layer.shadowOpacity = 0.25;

    CGFloat y = 8;
    CGFloat rowH = 21;
    CGFloat colW = 76;

    // 锁定图标（右上角）
    gLockIcon = [[UILabel alloc] initWithFrame:CGRectMake(148, 4, 18, 18)];
    gLockIcon.text = @"🔓";
    gLockIcon.font = [UIFont systemFontOfSize:10];
    [gHUD addSubview:gLockIcon];

    struct { NSString *icon; NSString *label; CGFloat x; CGFloat y; } rows[] = {
        {@"heart.fill",         @"电池健康", 8,  y},
        {@"bolt.fill",          @"电池电量", 8,  y + rowH},
        {@"waveform.path.ecg",  @"电池电流", 8,  y + rowH*2},
        {@"thermometer.medium", @"电池温度", 8,  y + rowH*3},
        {@"bolt.circle.fill",   @"电池电压", colW, y},
        {@"car.2.fill",         @"电瓶电压", colW, y + rowH},
        {@"thermometer.medium", @"车内温度", colW, y + rowH*2},
        {@"gearshape",          @"档位",     colW, y + rowH*3},
    };

    for (int i = 0; i < 8; i++) {
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(rows[i].x, rows[i].y + 2, 10, 10)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:7 weight:UIFontWeightRegular]];
            icon.tintColor = [UIColor systemBlueColor];
        }
        [gHUD addSubview:icon];

        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 13, rows[i].y, 48, rowH)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:8];
        lbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
        [gHUD addSubview:lbl];

        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 61, rows[i].y, colW - 61, rowH)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:9 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor blackColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [gHUD addSubview:gValues[i]];
    }

    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(8, y + rowH*4 + 2, 154, 0.5)];
    sep.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.08];
    [gHUD addSubview:sep];

    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, y + rowH*4 + 5, 154, 12)];
    gTimeLabel.font = [UIFont systemFontOfSize:8];
    gTimeLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    gTimeLabel.text = @"等待数据...";
    [gHUD addSubview:gTimeLabel];

    // 添加手势
    [gHUD addGestureRecognizer:[[UIPanGestureRecognizer alloc]
        initWithTarget:[BJPanHelper shared] action:@selector(handlePan:)]];
    [gHUD addGestureRecognizer:[[UIPinchGestureRecognizer alloc]
        initWithTarget:[BJPanHelper shared] action:@selector(handlePinch:)]];
    [gHUD addGestureRecognizer:[[UITapGestureRecognizer alloc]
        initWithTarget:[BJPanHelper shared] action:@selector(handleDoubleTap:)]];
    ((UITapGestureRecognizer *)gHUD.gestureRecognizers.lastObject).numberOfTapsRequired = 2;

    // 读取保存的位置
    BJLoadFrame();

    // 添加到窗口
    UIWindow *kw = nil;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { kw = w; break; }
    }
    if (kw) [kw addSubview:gHUD];
}

// ============================================================
// MARK: - 手势处理
// ============================================================

@implementation BJPanHelper
+ (instancetype)shared { static BJPanHelper *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJPanHelper new]; }); return o; }

- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (gLocked) return; // 锁定时禁止拖拽
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGFloat w = g.view.bounds.size.width * gScale;
        CGFloat h = g.view.bounds.size.height * gScale;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width;
        CGFloat sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(MAX(w/2, MIN(loc.x, sx-w/2)), MAX(40+h/2, MIN(loc.y, sy-h-40)));
    }
    if (g.state == UIGestureRecognizerStateEnded) {
        BJSaveFrame(); // 拖拽结束时保存位置
    }
}

- (void)handlePinch:(UIPinchGestureRecognizer *)g {
    if (gLocked) return;
    if (g.state == UIGestureRecognizerStateChanged) {
        gScale = g.scale;
        gScale = MAX(0.5, MIN(gScale, 2.0)); // 限制缩放范围
        g.view.transform = CGAffineTransformMakeScale(gScale, gScale);
    }
    if (g.state == UIGestureRecognizerStateEnded) {
        BJSaveFrame(); // 缩放结束时保存
    }
}

- (void)handleDoubleTap:(UITapGestureRecognizer *)g {
    gLocked = !gLocked;
    gLockIcon.text = gLocked ? @"🔒" : @"🔓";
    BJSaveFrame();

    // 锁定时轻微震动反馈
    if (gLocked) {
        UIImpactFeedbackGenerator *feedback = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
        [feedback impactOccurred];
    }
}

@end

// ============================================================
// MARK: - Hooks
// ============================================================

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJIsTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (!gHUD) {
                BJShowHUD();
                BJRefreshHUD();
            }
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJIsTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (!gHUD) {
                BJShowHUD();
                BJRefreshHUD();
            }
        });
}
%end

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ BJRefreshHUD(); });
    }
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] 插件已加载 bid=%@", [NSBundle mainBundle].bundleIdentifier);
    }
}
