#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

// ============================================================
// MARK: - 全局变量
// ============================================================

static UIView *gHUD = nil;
static UILabel *gLabel = nil;
static UILabel *gTimeLabel = nil;

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

// ============================================================
// MARK: - 从 NSUserDefaults 读取车辆状态
// ============================================================

static NSString *BJReadCarStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"] && ![key containsString:@"vehicle_status"]) continue;

        id val = dict[key];
        NSDictionary *sd = nil;

        if ([val isKindOfClass:[NSDictionary class]]) {
            sd = val;
        } else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) {
                id parsed = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil];
                if ([parsed isKindOfClass:[NSDictionary class]]) sd = parsed;
            }
        }

        if (!sd || !sd[@"batterySoc"]) continue;

        // 解析数值
        NSInteger soh = [sd[@"batSOH"] integerValue];
        NSInteger soc = [sd[@"batterySoc"] integerValue];
        double current = [sd[@"current"] doubleValue];
        double batTemp = [sd[@"batAvgTemp"] doubleValue];
        double voltage = [sd[@"voltage"] doubleValue];
        double lowBatVol = [sd[@"lowBatVol"] doubleValue];
        double interiorTemp = [sd[@"interiorTemperature"] doubleValue];
        NSInteger gear = [sd[@"autoGearStatus"] integerValue];
        NSString *time = sd[@"collectTime"] ?: @"--";

        // 档位
        NSString *gearStr = @"?";
        if (gear == 10) gearStr = @"P";
        else if (gear == 20) gearStr = @"R";
        else if (gear == 30) gearStr = @"N";
        else if (gear == 40) gearStr = @"D";

        // 拼装
        NSMutableString *h = [NSMutableString string];
        [h appendFormat:@" 电池健康    %ld%%\n", (long)soh];
        [h appendFormat:@" 电池电量    %ld%%\n", (long)soc];
        [h appendFormat:@" 电池电流    %.1fA\n", current];
        [h appendFormat:@" 电池温度    %.0f°C\n", batTemp];
        [h appendFormat:@" 电池电压    %.1fV\n", voltage];
        [h appendFormat:@" 电瓶电压    %.1fV\n", lowBatVol];
        [h appendFormat:@" 车内温度    %.0f°C\n", interiorTemp];
        [h appendFormat:@" 档位        %@", gearStr];

        return [h copy];
    }
    return nil;
}

static NSString *BJReadTime(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"] && ![key containsString:@"vehicle_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) sd = val;
        else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) { id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil]; if ([p isKindOfClass:[NSDictionary class]]) sd = p; }
        }
        if (sd && sd[@"collectTime"]) return sd[@"collectTime"];
    }
    return @"--";
}

// ============================================================
// MARK: - HUD 刷新
// ============================================================

static void BJRefreshHUD(void) {
    if (!gLabel) return;
    NSString *status = BJReadCarStatus();
    if (status) gLabel.text = status;
    if (gTimeLabel) {
        NSString *t = BJReadTime();
        // 截取 HH:mm:ss
        if ([t length] >= 19) t = [t substringFromIndex:11];
        gTimeLabel.text = [NSString stringWithFormat:@"更新: %@", t];
    }
}

// ============================================================
// MARK: - 定时器回调
// ============================================================

@interface BJTick : NSObject
+ (instancetype)shared;
- (void)onTick;
@end

@implementation BJTick
+ (instancetype)shared {
    static BJTick *o; static dispatch_once_t t;
    dispatch_once(&t, ^{ o = [BJTick new]; }); return o;
}
- (void)onTick {
    dispatch_async(dispatch_get_main_queue(), ^{
        BJRefreshHUD();
    });
}
@end

// ============================================================
// MARK: - 拖拽
// ============================================================

@interface BJPanHandler : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
@end

@implementation BJPanHandler
+ (instancetype)shared {
    static BJPanHandler *o; static dispatch_once_t t;
    dispatch_once(&t, ^{ o = [BJPanHandler new]; }); return o;
}
- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGFloat w = g.view.bounds.size.width, h = g.view.bounds.size.height;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width;
        CGFloat sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(
            MAX(w/2, MIN(loc.x, sx - w/2)),
            MAX(40 + h/2, MIN(loc.y, sy - h - 40))
        );
    }
}
@end

// ============================================================
// MARK: - 显示 HUD
// ============================================================

static void BJShowHUD(void) {
    if (gHUD) return;

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;

    // 白色半透明背景
    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - 190, 60, 180, 240)];
    gHUD.backgroundColor = [[UIColor colorWithWhite:1.0 alpha:0.75] colorWithAlphaComponent:0.75];
    gHUD.layer.cornerRadius = 16;
    gHUD.layer.borderWidth = 0.5;
    gHUD.layer.borderColor = [[UIColor colorWithWhite:0.8 alpha:0.5] CGColor];
    gHUD.layer.shadowColor = [UIColor blackColor].CGColor;
    gHUD.layer.shadowOffset = CGSizeMake(0, 2);
    gHUD.layer.shadowRadius = 10;
    gHUD.layer.shadowOpacity = 0.3;

    // 内容标签 - 黑色文字
    gLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 10, 156, 190)];
    gLabel.textColor = [UIColor blackColor];
    gLabel.font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightRegular];
    gLabel.numberOfLines = 0;
    gLabel.lineBreakMode = NSLineBreakByWordWrapping;
    gLabel.text = @"加载中...";
    [gHUD addSubview:gLabel];

    // 分割线
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(12, 202, 156, 0.5)];
    sep.backgroundColor = [[UIColor colorWithWhite:0.7 alpha:0.5] CGColor];
    [gHUD addSubview:sep];

    // 刷新时间 - 灰色小字
    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 206, 156, 14)];
    gTimeLabel.textColor = [[UIColor grayColor] colorWithAlphaComponent:0.7];
    gTimeLabel.font = [UIFont systemFontOfSize:9];
    gTimeLabel.text = @"更新: --";
    [gHUD addSubview:gTimeLabel];

    // 找 keyWindow
    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop

    if (keyWindow) {
        [keyWindow addSubview:gHUD];
    }

    // 拖拽手势
    [gHUD addGestureRecognizer:[[UIPanGestureRecognizer alloc]
        initWithTarget:[BJPanHandler shared] action:@selector(handlePan:)]];
}

// ============================================================
// MARK: - Logos Hooks
// ============================================================

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"] || [defaultName containsString:@"vehicle"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            BJRefreshHUD();
        });
    }
}
%end

%hook CBPeripheral
- (void)peripheral:(CBPeripheral *)peripheral
    didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic
                              error:(NSError *)error {
    %orig;
    if (!BJIsTarget() || error) return;
    NSString *uuid = characteristic.UUID.UUIDString ?: @"";
    if ([uuid isEqualToString:@"2A7F"] || [uuid isEqualToString:@"2a7f"]) {
        NSLog(@"[BJBLE] 控制数据 %luB", (unsigned long)characteristic.value.length);
    }
}
%end

// ============================================================
// MARK: - 构造函数
// ============================================================

%ctor {
    if (!BJIsTarget()) return;

    dispatch_async(dispatch_get_main_queue(), ^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
            dispatch_get_main_queue(), ^{
                BJShowHUD();
                BJRefreshHUD();

                [[NSRunLoop currentRunLoop] addTimer:
                    [NSTimer scheduledTimerWithTimeInterval:3.0
                        target:[BJTick shared]
                        selector:@selector(onTick)
                        userInfo:nil
                        repeats:YES]
                    forMode:NSRunLoopCommonModes];
            });
    });
}
