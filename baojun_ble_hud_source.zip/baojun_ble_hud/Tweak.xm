#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

static UIView *gHUD = nil;
static UILabel *gValues[8] = {nil};
static UILabel *gTimeLabel = nil;
static NSDateFormatter *gDateFmt = nil;
static NSTimer *gPollTimer = nil;
static BOOL gIsTargetApp = NO;

static BOOL BJCheckTarget(void) {
    if (gIsTargetApp) return YES;
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    gIsTargetApp = [bid isEqualToString:@"com.sgmw.baojunplus"] ||
                   [bid isEqualToString:@"com.cloudy.LingLingBang"];
    return gIsTargetApp;
}

static NSDictionary *BJReadCarStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) {
            sd = val;
        } else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) {
                id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil];
                if ([p isKindOfClass:[NSDictionary class]]) sd = p;
            }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

static void BJRefreshHUD(void) {
    if (!gHUD) return;
    NSDictionary *sd = BJReadCarStatus();
    if (!sd) return;

    NSString *keys[] = {
        @"batSOH", @"batterySoc", @"current", @"batAvgTemp",
        @"voltage", @"lowBatVol", @"interiorTemperature", @"autoGearStatus"
    };

    for (int i = 0; i < 8; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        switch (i) {
            case 2: gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]]; break;
            case 3: case 6: gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]]; break;
            case 4: case 5: gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]]; break;
            case 7: {
                NSInteger g = [val integerValue];
                gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
                break;
            }
            default: gValues[i].text = [NSString stringWithFormat:@"%@%%", val]; break;
        }
    }

    if (gTimeLabel && gDateFmt) {
        gTimeLabel.text = [NSString stringWithFormat:@"更新: %@", [gDateFmt stringFromDate:[NSDate date]]];
    }
}

static void BJScheduleTimer(void) {
    if (gPollTimer) return;
    gPollTimer = [NSTimer scheduledTimerWithTimeInterval:10.0 repeats:YES block:^(NSTimer *t) {
        BJRefreshHUD();
    }];
}

static void BJCreateHUD(void) {
    if (gHUD) return;

    gDateFmt = [[NSDateFormatter alloc] init];
    gDateFmt.dateFormat = @"HH:mm:ss";

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;
    CGFloat baseW = 150;
    CGFloat baseH = 270;

    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - baseW - 10, 80, baseW, baseH)];
    gHUD.backgroundColor = [[UIColor colorWithWhite:1.0 alpha:0.85] colorWithAlphaComponent:0.85];
    gHUD.layer.cornerRadius = 14;
    gHUD.layer.shadowColor = [UIColor blackColor].CGColor;
    gHUD.layer.shadowOffset = CGSizeMake(0, 2);
    gHUD.layer.shadowRadius = 10;
    gHUD.layer.shadowOpacity = 0.15;

    CGFloat startY = 8;
    CGFloat rowH = 27;

    struct { NSString *icon; NSString *label; } rows[] = {
        {@"heart.fill",      @"电池健康"},
        {@"bolt.fill",       @"电池电量"},
        {@"waveform",        @"电池电流"},
        {@"thermometer",     @"电池温度"},
        {@"bolt.circle",     @"电池电压"},
        {@"car",             @"电瓶电压"},
        {@"sun.max",         @"车内温度"},
        {@"gearshape",       @"档位"},
    };

    for (int i = 0; i < 8; i++) {
        CGFloat y = startY + i * rowH;

        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(10, y + 5, 14, 14)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:10 weight:UIFontWeightMedium]];
            icon.tintColor = [UIColor systemBlueColor];
        }
        [gHUD addSubview:icon];

        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(30, y + 3, 50, 18)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:9];
        lbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
        [gHUD addSubview:lbl];

        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(85, y + 3, 55, 18)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor blackColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [gHUD addSubview:gValues[i]];
    }

    CGFloat sepY = startY + 8 * rowH + 2;
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(10, sepY, baseW - 20, 0.5)];
    sep.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.1];
    [gHUD addSubview:sep];

    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, sepY + 4, baseW - 20, 14)];
    gTimeLabel.font = [UIFont systemFontOfSize:9];
    gTimeLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    gTimeLabel.text = @"更新: --:--:--";
    [gHUD addSubview:gTimeLabel];

    UIWindow *kw = nil;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { kw = w; break; }
    }
    if (kw) [kw addSubview:gHUD];

    BJRefreshHUD();
}

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJCheckTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
            BJScheduleTimer();
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJCheckTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJCreateHUD();
        });
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] v3.0 loaded %@", [NSBundle mainBundle].bundleIdentifier);
    }
}
