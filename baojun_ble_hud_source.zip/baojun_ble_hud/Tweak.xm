#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BJPanHelper : NSObject
+ (instancetype)shared;
- (void)BJPan:(UIPanGestureRecognizer *)g;
@end

static UIView *gHUD = nil;
static UILabel *gValues[8];
static UILabel *gTimeLabel = nil;
static NSDateFormatter *gFmt = nil;

static BOOL BJIsTarget(void) {
    return [[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.sgmw.baojunplus"];
}

static NSDictionary *BJReadStatus(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) sd = val;
        else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) { id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil]; if ([p isKindOfClass:[NSDictionary class]]) sd = p; }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

static void BJRefreshHUD(void) {
    if (!gHUD) return;
    NSDictionary *sd = BJReadStatus();
    if (!sd) return;

    NSString *keys[] = {@"batSOH", @"batterySoc", @"current", @"batAvgTemp", @"voltage", @"lowBatVol", @"interiorTemperature", @"autoGearStatus"};
    for (int i = 0; i < 8; i++) {
        id val = sd[keys[i]];
        if (!val || !gValues[i]) continue;
        if (i == 2) gValues[i].text = [NSString stringWithFormat:@"%.1fA", [val doubleValue]];
        else if (i == 3 || i == 6) gValues[i].text = [NSString stringWithFormat:@"%.0f°C", [val doubleValue]];
        else if (i == 4 || i == 5) gValues[i].text = [NSString stringWithFormat:@"%.1fV", [val doubleValue]];
        else if (i == 7) {
            NSInteger g = [val integerValue];
            gValues[i].text = (g==10)?@"P":(g==20)?@"R":(g==30)?@"N":(g==40)?@"D":[NSString stringWithFormat:@"%ld",(long)g];
        }
        else gValues[i].text = [NSString stringWithFormat:@"%@%%", val];
    }

    if (gTimeLabel) {
        NSString *t = sd[@"collectTime"] ?: @"--";
        if ([t length] >= 19) t = [t substringFromIndex:11];
        gTimeLabel.text = [NSString stringWithFormat:@"更新: %@", t];
    }
}

static void BJShowHUD(void) {
    if (gHUD) return;

    gFmt = [[NSDateFormatter alloc] init];
    gFmt.dateFormat = @"HH:mm:ss";

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;

    // 悬浮卡片 - 白色半透明
    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - 180, 80, 170, 200)];
    gHUD.backgroundColor = [[UIColor colorWithWhite:1.0 alpha:0.80] colorWithAlphaComponent:0.80];
    gHUD.layer.cornerRadius = 14;
    gHUD.layer.shadowColor = [UIColor blackColor].CGColor;
    gHUD.layer.shadowOffset = CGSizeMake(0, 2);
    gHUD.layer.shadowRadius = 8;
    gHUD.layer.shadowOpacity = 0.25;

    CGFloat y = 8;
    CGFloat rowH = 21;
    CGFloat colW = 76;

    struct { NSString *icon; NSString *label; int tag; CGFloat x; CGFloat y; } rows[] = {
        {@"heart.fill",         @"电池健康", 0, 8,  y},
        {@"bolt.fill",          @"电池电量", 1, 8,  y + rowH},
        {@"waveform.path.ecg",  @"电池电流", 2, 8,  y + rowH*2},
        {@"thermometer.medium", @"电池温度", 3, 8,  y + rowH*3},
        {@"bolt.circle.fill",   @"电池电压", 4, colW, y},
        {@"car.2.fill",         @"电瓶电压", 5, colW, y + rowH},
        {@"thermometer.medium", @"车内温度", 6, colW, y + rowH*2},
        {@"gearshape",          @"档位",     7, colW, y + rowH*3},
    };

    for (int i = 0; i < 8; i++) {
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(rows[i].x, rows[i].y + 2, 10, 10)];
        UIImage *img = [UIImage systemImageNamed:rows[i].icon];
        if (img) {
            icon.image = [img imageWithConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:7 weight:UIFontWeightRegular]];
            icon.tintColor = [UIColor systemBlueColor];
        }
        [gHUD addSubview:icon];

        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 13, rows[i].y, 48, rowH)];
        lbl.text = rows[i].label;
        lbl.font = [UIFont systemFontOfSize:8];
        lbl.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
        [gHUD addSubview:lbl];

        gValues[i] = [[UILabel alloc] initWithFrame:CGRectMake(rows[i].x + 61, rows[i].y, colW - 61, rowH)];
        gValues[i].font = [UIFont monospacedDigitSystemFontOfSize:9 weight:UIFontWeightMedium];
        gValues[i].textColor = [UIColor blackColor];
        gValues[i].textAlignment = NSTextAlignmentRight;
        gValues[i].text = @"--";
        [gHUD addSubview:gValues[i]];
    }

    // 底部时间
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(8, y + rowH*4 + 2, 154, 0.5)];
    sep.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.08];
    [gHUD addSubview:sep];

    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, y + rowH*4 + 5, 154, 12)];
    gTimeLabel.font = [UIFont systemFontOfSize:8];
    gTimeLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    gTimeLabel.text = @"更新: --";
    [gHUD addSubview:gTimeLabel];

    // 添加到窗口
    UIWindow *kw = nil;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { kw = w; break; }
    }
    if (kw) [kw addSubview:gHUD];

    // 拖拽
    [gHUD addGestureRecognizer:[[UIPanGestureRecognizer alloc]
        initWithTarget:[BJPanHelper shared] action:@selector(BJPan:)]];
}

@interface BJPanHelper : NSObject
+ (instancetype)shared;
- (void)BJPan:(UIPanGestureRecognizer *)g;
@end

@implementation BJPanHelper
+ (instancetype)shared { static BJPanHelper *o; static dispatch_once_t t; dispatch_once(&t, ^{ o = [BJPanHelper new]; }); return o; }
- (void)BJPan:(UIPanGestureRecognizer *)g {
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGFloat w = g.view.bounds.size.width, h = g.view.bounds.size.height;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width, sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(MAX(w/2, MIN(loc.x, sx-w/2)), MAX(40+h/2, MIN(loc.y, sy-h-40)));
    }
}
@end

// ============================================================
// MARK: - Hooks
// ============================================================

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJIsTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (!gHUD) {
                BJShowHUD();
                BJRefreshHUD();
            }
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJIsTarget()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (!gHUD) {
                BJShowHUD();
                BJRefreshHUD();
            }
        });
}
%end

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ BJRefreshHUD(); });
    }
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] 插件已加载 bid=%@", [NSBundle mainBundle].bundleIdentifier);
    }
}
