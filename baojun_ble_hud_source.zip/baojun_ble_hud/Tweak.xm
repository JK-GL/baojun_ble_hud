#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

// ============================================================
// MARK: - 全局变量
// ============================================================

static UIView *gHUD = nil;
static UILabel *gTitleLabel = nil;
static UILabel *gSocLabel = nil;
static UIView *gSocBarBg = nil;
static UIView *gSocBarFill = nil;
static UILabel *gRangeLabel = nil;
static UILabel *gInfoLabel = nil;
static UILabel *gStatusLabel = nil;
static UILabel *gTimeLabel = nil;

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

// ============================================================
// MARK: - 从 NSUserDefaults 读取车辆状态
// ============================================================

static NSDictionary *BJReadCarStatusDict(void) {
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];
    for (NSString *key in dict) {
        if (![key containsString:@"car_status"] && ![key containsString:@"vehicle_status"]) continue;
        id val = dict[key];
        NSDictionary *sd = nil;
        if ([val isKindOfClass:[NSDictionary class]]) {
            sd = val;
        } else if ([val isKindOfClass:[NSString class]] && [(NSString *)val length] > 10) {
            NSData *jd = [(NSString *)val dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) {
                id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil];
                if ([p isKindOfClass:[NSDictionary class]]) sd = p;
            }
        }
        if (sd && sd[@"batterySoc"]) return sd;
    }
    return nil;
}

// ============================================================
// MARK: - 刷新 HUD 内容
// ============================================================

static void BJRefreshHUD(void) {
    NSDictionary *sd = BJReadCarStatusDict();
    if (!sd || !gSocLabel) return;

    NSInteger soc = [sd[@"batterySoc"] integerValue];
    double leftPower = [sd[@"leftBatteryPower"] doubleValue];
    NSInteger leftMileage = [sd[@"leftMileage"] integerValue];
    NSInteger leftFuel = [sd[@"leftFuel"] integerValue];
    NSInteger mileage = [sd[@"mileage"] integerValue];
    NSInteger doorLock = [sd[@"doorLockStatus"] integerValue]; // 0=锁 1=开
    NSInteger acOn = [sd[@"acStatus"] integerValue];
    double interiorTemp = [sd[@"interiorTemperature"] doubleValue];
    double batTemp = [sd[@"batAvgTemp"] doubleValue];
    double voltage = [sd[@"voltage"] doubleValue];
    double current = [sd[@"current"] doubleValue];
    NSInteger soh = [sd[@"batSOH"] integerValue];
    NSInteger charging = [sd[@"charging"] integerValue];
    NSString *time = sd[@"collectTime"] ?: @"--";
    NSInteger gear = [sd[@"autoGearStatus"] integerValue];

    // 档位
    NSString *gearStr = @"?";
    if (gear == 10) gearStr = @"P";
    else if (gear == 20) gearStr = @"R";
    else if (gear == 30) gearStr = @"N";
    else if (gear == 40) gearStr = @"D";

    // ---- 电量行 ----
    NSString *chargeStr = charging ? @"  ⚡充电" : @"";
    gSocLabel.text = [NSString stringWithFormat:@"%ld%%  %.1fkWh%@", (long)soc, leftPower, chargeStr];

    // ---- 电量条 ----
    CGFloat ratio = MAX(0, MIN(1.0, soc / 100.0));
    if (soc > 50)
        gSocBarFill.backgroundColor = [UIColor colorWithRed:0.2 green:0.8 blue:0.4 alpha:1];
    else if (soc > 20)
        gSocBarFill.backgroundColor = [UIColor colorWithRed:1.0 green:0.7 blue:0.0 alpha:1];
    else
        gSocBarFill.backgroundColor = [UIColor colorWithRed:1.0 green:0.3 blue:0.3 alpha:1];
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = gSocBarFill.frame;
        f.size.width = 152 * ratio;
        gSocBarFill.frame = f;
    }];

    // ---- 续航 ----
    gRangeLabel.text = [NSString stringWithFormat:@"⚡电%ldkm  ⛽油%ldkm  📏%ldkm",
        (long)leftMileage, (long)leftFuel, (long)mileage];

    // ---- 电池信息 ----
    gInfoLabel.text = [NSString stringWithFormat:@"🔋%.0fV %.1fA  SOH%ld%%",
        voltage, current, (long)soh];

    // ---- 车辆状态 ----
    // 注意: doorLockStatus 0=已锁 1=未锁
    NSString *doorStr = (doorLock == 0) ? @"🔒锁" : @"🔓开";
    NSString *acStr = acOn ? @"❄️开" : @"❄️关";
    gStatusLabel.text = [NSString stringWithFormat:@"%@  %@  ⚙️%@  🌡️%.0f°/%.0f°",
        doorStr, acStr, gearStr, interiorTemp, batTemp];

    // ---- 时间 ----
    NSString *shortTime = time;
    if ([time length] >= 19) shortTime = [time substringFromIndex:11];
    gTimeLabel.text = [NSString stringWithFormat:@"🕐 %@", shortTime];
}

// ============================================================
// MARK: - 定时器
// ============================================================

@interface BJTick : NSObject
+ (instancetype)shared;
- (void)onTick;
@end

@implementation BJTick
+ (instancetype)shared {
    static BJTick *o; static dispatch_once_t t;
    dispatch_once(&t, ^{ o = [BJTick new]; }); return o;
}
- (void)onTick {
    dispatch_async(dispatch_get_main_queue(), ^{ BJRefreshHUD(); });
}
@end

// ============================================================
// MARK: - 显示 HUD
// ============================================================

static void BJShowHUD(void) {
    if (gHUD) return;

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;
    CGFloat hudW = 172, hudH = 150;

    // 主容器
    gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - hudW - 8, 50, hudW, hudH)];
    gHUD.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.9];
    gHUD.layer.cornerRadius = 14;
    gHUD.layer.borderWidth = 1;
    gHUD.layer.borderColor = [[UIColor colorWithRed:0.15 green:0.75 blue:0.4 alpha:0.9] CGColor];

    CGFloat px = 10, pw = hudW - 20, cy = 0;

    // 标题
    gTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(px, cy, pw, 20)];
    gTitleLabel.text = @"🚗 宝骏云海";
    gTitleLabel.textColor = [UIColor whiteColor];
    gTitleLabel.font = [UIFont boldSystemFontOfSize:14];
    [gHUD addSubview:gTitleLabel];
    cy += 22;

    // 电量百分比 + kWh
    gSocLabel = [[UILabel alloc] initWithFrame:CGRectMake(px, cy, pw, 18)];
    gSocLabel.textColor = [UIColor colorWithRed:0.2 green:0.85 blue:0.4 alpha:1];
    gSocLabel.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightBold];
    gSocLabel.text = @"--%";
    [gHUD addSubview:gSocLabel];
    cy += 20;

    // 电量进度条背景
    gSocBarBg = [[UIView alloc] initWithFrame:CGRectMake(px, cy, pw, 6)];
    gSocBarBg.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.15];
    gSocBarBg.layer.cornerRadius = 3;
    [gHUD addSubview:gSocBarBg];

    gSocBarFill = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 76, 6)];
    gSocBarFill.backgroundColor = [UIColor colorWithRed:0.2 green:0.8 blue:0.4 alpha:1];
    gSocBarFill.layer.cornerRadius = 3;
    [gSocBarBg addSubview:gSocBarFill];
    cy += 10;

    // 续航
    gRangeLabel = [[UILabel alloc] initWithFrame:CGRectMake(px, cy, pw, 16)];
    gRangeLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.9];
    gRangeLabel.font = [UIFont systemFontOfSize:10.5];
    gRangeLabel.text = @"--";
    [gHUD addSubview:gRangeLabel];
    cy += 17;

    // 电池信息
    gInfoLabel = [[UILabel alloc] initWithFrame:CGRectMake(px, cy, pw, 16)];
    gInfoLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.75];
    gInfoLabel.font = [UIFont monospacedDigitSystemFontOfSize:10 weight:UIFontWeightRegular];
    gInfoLabel.text = @"--";
    [gHUD addSubview:gInfoLabel];
    cy += 17;

    // 车门/空调/档位/温度
    gStatusLabel = [[UILabel alloc] initWithFrame:CGRectMake(px, cy, pw, 16)];
    gStatusLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.85];
    gStatusLabel.font = [UIFont systemFontOfSize:10.5];
    gStatusLabel.text = @"--";
    [gHUD addSubview:gStatusLabel];
    cy += 17;

    // 分割线
    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(px, cy, pw, 0.5)];
    sep.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.2];
    [gHUD addSubview:sep];
    cy += 4;

    // 时间
    gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(px, cy, pw, 14)];
    gTimeLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.45];
    gTimeLabel.font = [UIFont systemFontOfSize:9];
    gTimeLabel.text = @"🕐 --:--:--";
    [gHUD addSubview:gTimeLabel];

    // 添加到 keyWindow
    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop
    if (keyWindow) {
        [keyWindow addSubview:gHUD];
        NSLog(@"[BJBLE] HUD 已显示");
    }

    // 拖拽
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]
        initWithTarget:[BJTick shared] action:@selector(handlePan:)];
    [gHUD addGestureRecognizer:pan];
}

// ============================================================
// MARK: - Logos Hooks
// ============================================================

%hook NSUserDefaults
- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;
    if ([defaultName containsString:@"car_status"] || [defaultName containsString:@"vehicle"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ BJRefreshHUD(); });
    }
}
%end

%hook CBPeripheral
- (void)peripheral:(CBPeripheral *)peripheral
    didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic
                              error:(NSError *)error {
    %orig;
    if (!BJIsTarget() || error) return;
    NSString *uuid = characteristic.UUID.UUIDString ?: @"";
    if ([uuid isEqualToString:@"2A7F"] || [uuid isEqualToString:@"2a7f"]) {
        NSLog(@"[BJBLE] 收到控制数据 %luB", (unsigned long)characteristic.value.length);
    }
}
%end

// ============================================================
// MARK: - 拖拽手势
// ============================================================

%hook BJTick
- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGFloat w = g.view.bounds.size.width, h = g.view.bounds.size.height;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width;
        CGFloat sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(
            MAX(w/2, MIN(loc.x, sx - w/2)),
            MAX(h/2, MIN(loc.y, sy - h - 30))
        );
    }
}
%end

// ============================================================
// MARK: - 构造函数
// ============================================================

%ctor {
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] ====== 宝骏云海 BLE HUD 已加载 ======");

    dispatch_async(dispatch_get_main_queue(), ^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
            dispatch_get_main_queue(), ^{
                BJShowHUD();
                BJRefreshHUD();
                if (gSocLabel && [gSocLabel.text isEqualToString:@"--%  0.0kWh"]) {
                    gSocLabel.text = @"等待数据...";
                }

                // 定时刷新 3 秒
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:3.0
                    target:[BJTick shared]
                    selector:@selector(onTick)
                    userInfo:nil
                    repeats:YES];
                [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
                NSLog(@"[BJBLE] 定时刷新已启动");
            });
    });
}
