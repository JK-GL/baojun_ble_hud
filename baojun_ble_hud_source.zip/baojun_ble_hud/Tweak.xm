#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

static UIView *gHUD = nil;

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.sgmw.baojunplus"]) return;
    if (gHUD) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            CGFloat sw = [UIScreen mainScreen].bounds.size.width;
            gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw-170, 80, 160, 120)];
            gHUD.backgroundColor = [UIColor whiteColor];
            gHUD.layer.cornerRadius = 12;
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 140, 100)];
            lbl.text = @"HUD OK";
            lbl.textColor = [UIColor blackColor];
            lbl.font = [UIFont boldSystemFontOfSize:18];
            [gHUD addSubview:lbl];
            UIWindow *kw = nil;
            for (UIWindow *w in [UIApplication sharedApplication].windows) {
                if (w.isKeyWindow) { kw = w; break; }
            }
            if (kw) [kw addSubview:gHUD];
        });
}
%end

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.sgmw.baojunplus"]) return;
    if (gHUD) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            CGFloat sw = [UIScreen mainScreen].bounds.size.width;
            gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw-170, 80, 160, 120)];
            gHUD.backgroundColor = [UIColor whiteColor];
            gHUD.layer.cornerRadius = 12;
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 140, 100)];
            lbl.text = @"HUD OK";
            lbl.textColor = [UIColor blackColor];
            lbl.font = [UIFont boldSystemFontOfSize:18];
            [gHUD addSubview:lbl];
            UIWindow *kw = nil;
            for (UIWindow *w in [UIApplication sharedApplication].windows) {
                if (w.isKeyWindow) { kw = w; break; }
            }
            if (kw) [kw addSubview:gHUD];
        });
}
%end

%ctor {
    @autoreleasepool {
        NSLog(@"[BJBLE] loaded %@", [NSBundle mainBundle].bundleIdentifier);
    }
}
