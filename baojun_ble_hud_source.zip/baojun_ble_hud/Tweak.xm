#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

static UIWindow *gProbeWindow = nil;

// ============================================================
// MARK: - 探测所有视图
// ============================================================

static NSString *BJProbeAllViews(void) {
    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop
    if (!keyWindow) return @"未找到 keyWindow";

    NSMutableString *log = [NSMutableString string];
    [log appendFormat:@"keyWindow: {{%.0f,%.0f,%.0f,%.0f}} subviews=%lu\n\n",
        keyWindow.frame.origin.x, keyWindow.frame.origin.y,
        keyWindow.frame.size.width, keyWindow.frame.size.height,
        (unsigned long)keyWindow.subviews.count];

    void (^dumpView)(UIView *, int);
    __block __weak void (^weakDump)(UIView *, int);
    weakDump = ^(UIView *view, int depth) {
        if (!view || depth > 8) return;
        CGRect f = view.frame;
        NSString *cls = NSStringFromClass([view class]);

        BOOL isKey = [view isKindOfClass:[UINavigationBar class]] ||
                     [view isKindOfClass:[UITabBar class]] ||
                     [view isKindOfClass:[UIScrollView class]] ||
                     [cls containsString:@"Flutter"] ||
                     [cls containsString:@"TabBar"] ||
                     [cls containsString:@"Nav"] ||
                     f.size.width > 300;

        if (isKey) {
            NSString *indent = @"";
            for (int i = 0; i < depth; i++) indent = [indent stringByAppendingString:@"  "];
            [log appendFormat:@"%@[%d] %@ {{%.0f,%.0f,%.0f,%.0f}} sub=%lu",
                indent, depth, cls, f.origin.x, f.origin.y, f.size.width, f.size.height,
                (unsigned long)view.subviews.count];
            if ([view isKindOfClass:[UINavigationBar class]]) [log appendString:@" ★NavBar"];
            if ([view isKindOfClass:[UITabBar class]]) [log appendString:@" ★TabBar"];
            if ([cls containsString:@"Flutter"]) [log appendString:@" ★Flutter"];
            [log appendString:@"\n"];
        }
        for (UIView *sub in view.subviews) {
            weakDump(sub, depth + 1);
        }
    };
    dumpView = weakDump;
    dumpView(keyWindow, 0);
    return log;
}

// ============================================================
// MARK: - 显示探测窗口 (最高层级)
// ============================================================

static void BJShowProbeWindow(void) {
    if (gProbeWindow) return;

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;
    CGFloat sh = [UIScreen mainScreen].bounds.size.height;

    gProbeWindow = [[UIWindow alloc] initWithFrame:CGRectMake(0, 0, sw, sh)];
    gProbeWindow.windowLevel = UIWindowLevelAlert + 100;
    gProbeWindow.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.95];
    gProbeWindow.hidden = NO;

    // 标题
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(16, 50, sw - 100, 24)];
    title.text = @"📋 视图层级";
    title.textColor = [UIColor whiteColor];
    title.font = [UIFont boldSystemFontOfSize:14];
    [gProbeWindow addSubview:title];

    // 日志文本
    UITextView *tv = [[UITextView alloc] initWithFrame:CGRectMake(8, 80, sw - 16, sh - 130)];
    tv.backgroundColor = [UIColor clearColor];
    tv.textColor = [UIColor greenColor];
    tv.font = [UIFont fontWithName:@"Menlo" size:10];
    tv.editable = NO;
    tv.text = BJProbeAllViews();
    tv.tag = 777;
    [gProbeWindow addSubview:tv];

    // 关闭按钮
    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    closeBtn.frame = CGRectMake(sw - 70, 50, 50, 24);
    [closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [closeBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    closeBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    [closeBtn addTarget:[NSObject class] action:@selector(BJCloseProbe) forControlEvents:UIControlEventTouchUpInside];
    [gProbeWindow addSubview:closeBtn];

    NSLog(@"[BJBLE] 探测窗口已显示");
}

// ============================================================
// MARK: - Hooks
// ============================================================

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] applicationDidBecomeActive");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJShowProbeWindow();
        });
}
%end

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] FlutterViewController viewDidAppear");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (!gProbeWindow) BJShowProbeWindow();
        });
}
%end

%ctor {
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] ====== 视图探测插件已加载 ======");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (!gProbeWindow) BJShowProbeWindow();
        });
}
