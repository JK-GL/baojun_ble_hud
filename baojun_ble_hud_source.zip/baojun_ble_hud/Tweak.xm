#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <objc/runtime.h>

// ============================================================
// MARK: - 工具函数
// ============================================================

// ============================================================
// MARK: - 前向声明
// ============================================================

@interface BJPanHandler : NSObject
+ (instancetype)shared;
- (void)handlePan:(UIPanGestureRecognizer *)g;
@end

@interface BJRefreshHandler : NSObject
+ (instancetype)shared;
- (void)tick;
@end

// ============================================================
// MARK: - 工具函数
// ============================================================

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

// ============================================================
// MARK: - HUD 悬浮窗
// ============================================================

static UIView *gHUD = nil;
static UILabel *gLabel = nil;
static UILabel *gTimeLabel = nil;
static NSDateFormatter *gFmt = nil;

static void BJShowHUD(void) {
    if (gHUD) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        gFmt = [[NSDateFormatter alloc] init];
        gFmt.dateFormat = @"HH:mm:ss";

        CGFloat sw = [UIScreen mainScreen].bounds.size.width;

        // 悬浮窗
        gHUD = [[UIView alloc] initWithFrame:CGRectMake(sw - 180, 60, 172, 200)];
        gHUD.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.88];
        gHUD.layer.cornerRadius = 14;
        gHUD.layer.borderWidth = 1;
        gHUD.layer.borderColor = [[UIColor colorWithRed:0.2 green:0.8 blue:0.4 alpha:0.8] CGColor];
        gHUD.layer.shadowColor = [UIColor blackColor].CGColor;
        gHUD.layer.shadowOffset = CGSizeMake(0, 2);
        gHUD.layer.shadowRadius = 8;
        gHUD.layer.shadowOpacity = 0.5;

        // 标题
        UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, 152, 18)];
        title.text = @"🚗 宝骏云海";
        title.textColor = [UIColor whiteColor];
        title.font = [UIFont boldSystemFontOfSize:13];
        [gHUD addSubview:title];

        // 分割线
        UIView *line = [[UILabel alloc] initWithFrame:CGRectMake(10, 26, 152, 0.5)];
        line.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.3];
        [gHUD addSubview:line];

        // 主要内容
        gLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 30, 152, 140)];
        gLabel.textColor = [UIColor whiteColor];
        gLabel.font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightMedium];
        gLabel.numberOfLines = 0;
        gLabel.lineBreakMode = NSLineBreakByWordWrapping;
        gLabel.text = @"正在加载...";
        [gHUD addSubview:gLabel];

        // 底部时间
        gTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 175, 152, 16)];
        gTimeLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.5];
        gTimeLabel.font = [UIFont systemFontOfSize:9];
        gTimeLabel.text = [NSString stringWithFormat:@"🕐 %@", [gFmt stringFromDate:[NSDate date]]];
        [gHUD addSubview:gTimeLabel];

        // 加载到 keyWindow
        UIWindow *w = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        for (UIWindow *win in [UIApplication sharedApplication].windows) {
            if (win.isKeyWindow) { w = win; break; }
        }
#pragma clang diagnostic pop
        if (w) {
            [w addSubview:gHUD];
            NSLog(@"[BJBLE] ✅ HUD 已显示");
        }

        // 拖拽手势
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]
            initWithTarget:[BJPanHandler shared] action:@selector(handlePan:)];
        [gHUD addGestureRecognizer:pan];
    });
}

static NSString *BJDoorStatus(NSInteger locked) {
    return locked ? @"🔒 已锁" : @"🔓 未锁";
}

static NSString *BJACStatus(NSInteger on) {
    return on ? @"❄️ 开启" : @"❄️ 关闭";
}

static NSString *BJGearStatus(NSInteger gear) {
    switch (gear) {
        case 10: return @"P";
        case 20: return @"R";
        case 30: return @"N";
        case 40: return @"D";
        default: return [NSString stringWithFormat:@"%ld", (long)gear];
    }
}

static NSString *BJReadStatus(void) {
    NSDictionary *d = [[NSUserDefaults standardUserDefaults] dictionaryRepresentation];

    for (NSString *k in d) {
        id v = d[k];
        NSDictionary *sd = nil;

        if ([v isKindOfClass:[NSDictionary class]]) {
            sd = v;
        } else if ([v isKindOfClass:[NSString class]] && [(NSString *)v length] > 20) {
            NSData *jd = [(NSString *)v dataUsingEncoding:NSUTF8StringEncoding];
            if (jd) {
                id p = [NSJSONSerialization JSONObjectWithData:jd options:0 error:nil];
                if ([p isKindOfClass:[NSDictionary class]]) sd = p;
            }
        }

        if (!sd) continue;
        if (!sd[@"batterySoc"] && !sd[@"mileage"] && !sd[@"collectTime"]) continue;

        // 数值解析
        NSInteger soc = [sd[@"batterySoc"] integerValue];
        double leftPower = [sd[@"leftBatteryPower"] doubleValue];
        NSInteger leftMileage = [sd[@"leftMileage"] integerValue];
        NSInteger leftFuel = [sd[@"leftFuel"] integerValue];
        NSInteger mileage = [sd[@"mileage"] integerValue];
        NSInteger doorLock = [sd[@"doorLockStatus"] integerValue];
        NSInteger acOn = [sd[@"acStatus"] integerValue];
        double interiorTemp = [sd[@"interiorTemperature"] doubleValue];
        double batTemp = [sd[@"batAvgTemp"] doubleValue];
        double voltage = [sd[@"voltage"] doubleValue];
        double current = [sd[@"current"] doubleValue];
        NSInteger soh = [sd[@"batSOH"] integerValue];
        NSInteger gear = [sd[@"autoGearStatus"] integerValue];
        NSInteger charging = [sd[@"charging"] integerValue];
        NSString *time = sd[@"collectTime"] ?: @"--";

        // 拼装中文 HUD
        NSMutableString *h = [NSMutableString string];

        // 电量行
        NSString *chargeIcon = charging ? @"⚡充电中" : @"";
        [h appendFormat:@"🔋 %ld%%  %.1fkWh %@\n", (long)soc, leftPower, chargeIcon];

        // 续航行
        [h appendFormat:@"🛣️ 电%ldkm 油%ldkm\n", (long)leftMileage, (long)leftFuel];

        // 总里程
        [h appendFormat:@"📊 里程%ldkm\n", (long)mileage];

        // 电池信息
        [h appendFormat:@"⚡ %.0fV %.1fA SOH%ld%%\n", voltage, current, (long)soh];

        // 车门 + 空调
        [h appendFormat:@"%@ %@\n", BJDoorStatus(doorLock), BJACStatus(acOn)];

        // 档位
        [h appendFormat:@"⚙️ 档位:%@\n", BJGearStatus(gear)];

        // 温度
        [h appendFormat:@"🌡️ 车%.0f° 电%.0f°\n", interiorTemp, batTemp];

        // 更新时间（只显示时分秒）
        NSString *shortTime = time;
        if (time.length >= 19) {
            shortTime = [time substringFromIndex:11]; // HH:mm:ss
        }
        [h appendFormat:@"🕐 %@", shortTime];

        return [h copy];
    }
    return nil;
}

// ============================================================
// MARK: - 定时刷新
// ============================================================

static NSTimer *gRefreshTimer = nil;

static void BJStartRefreshTimer(void) {
    if (gRefreshTimer) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        gRefreshTimer = [NSTimer scheduledTimerWithTimeInterval:3.0
            target:[BJRefreshHandler shared]
            selector:@selector(tick)
            userInfo:nil
            repeats:YES];
        NSLog(@"[BJBLE] ⏰ 定时刷新已启动 (3秒)");
    });
}

// BJRefreshHandler declared above

@implementation BJRefreshHandler
+ (instancetype)shared {
    static BJRefreshHandler *h; static dispatch_once_t t;
    dispatch_once(&t, ^{ h = [BJRefreshHandler new]; }); return h;
}
- (void)tick {
    NSString *s = BJReadStatus();
    if (s && gLabel) {
        gLabel.text = s;
    }
    if (gTimeLabel && gFmt) {
        gTimeLabel.text = [NSString stringWithFormat:@"🕐 %@", [gFmt stringFromDate:[NSDate date]]];
    }
}
@end

// ============================================================
// MARK: - 拖拽处理
// ============================================================

@implementation BJPanHandler
+ (instancetype)shared {
    static BJPanHandler *h; static dispatch_once_t t;
    dispatch_once(&t, ^{ h = [BJPanHandler new]; }); return h;
}
- (void)handlePan:(UIPanGestureRecognizer *)g {
    if (g.state == UIGestureRecognizerStateChanged) {
        CGPoint loc = [g locationInView:g.view.superview];
        CGFloat w = g.view.bounds.size.width, h = g.view.bounds.size.height;
        CGFloat sx = [UIScreen mainScreen].bounds.size.width;
        CGFloat sy = [UIScreen mainScreen].bounds.size.height;
        g.view.center = CGPointMake(
            MAX(w/2, MIN(loc.x, sx - w/2)),
            MAX(40 + h/2, MIN(loc.y, sy - h - 40))
        );
    }
}
@end

// ============================================================
// MARK: - NSUserDefaults Hook - 实时捕获状态更新
// ============================================================

%hook NSUserDefaults

- (void)setObject:(id)value forKey:(NSString *)defaultName {
    %orig;
    if (!BJIsTarget()) return;

    // 监控所有车辆相关写入
    BOOL isCarData = [defaultName containsString:@"car_status"] ||
                     [defaultName containsString:@"carStatus"] ||
                     [defaultName containsString:@"vehicle"] ||
                     [defaultName containsString:@"status"];

    if (isCarData) {
        NSLog(@"[BJBLE] 💾 状态更新: %@", defaultName);
        // 立即刷新 HUD
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *s = BJReadStatus();
            if (s && gLabel) gLabel.text = s;
        });
    }
}

%end

// ============================================================
// MARK: - CoreBluetooth Hook - 实时 BLE 数据监控
// ============================================================

%hook CBPeripheral

- (void)peripheral:(CBPeripheral *)peripheral
    didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic
                              error:(NSError *)error {
    %orig;
    if (!BJIsTarget() || error || !characteristic.value) return;

    NSData *data = characteristic.value;
    NSString *uuid = characteristic.UUID.UUIDString ?: @"";

    // 只记录控制特征 2a7f 的数据（车辆状态数据）
    if ([uuid isEqualToString:@"2A7F"] || [uuid isEqualToString:@"2a7f"]) {
        NSLog(@"[BJBLE] 📩 控制数据 %luB", (unsigned long)data.length);

        // 尝试解析非加密部分（字节0-1可能是明文）
        if (data.length >= 2) {
            const unsigned char *bytes = (const unsigned char *)data.bytes;
            NSLog(@"[BJBLE] 📊 数据类型: 0x%02X 0x%02X", bytes[0], bytes[1]);
        }
    }
}

%end

// ============================================================
// MARK: - 构造函数
// ============================================================

%ctor {
    if (!BJIsTarget()) return;

    NSLog(@"[BJBLE] =============================================");
    NSLog(@"[BJBLE] 🚀 宝骏云海 BLE HUD v0.1 已加载!");
    NSLog(@"[BJBLE] 📱 Bundle: %@", [NSBundle mainBundle].bundleIdentifier);
    NSLog(@"[BJBLE] =============================================");

    // 延时 2 秒后显示 HUD + 启动定时刷新
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJShowHUD();
            NSString *s = BJReadStatus();
            if (s && gLabel) {
                gLabel.text = s;
                NSLog(@"[BJBLE] ✅ 初始状态已读取");
            } else {
                gLabel.text = @"等待数据...\n请打开宝骏App\n状态会自动更新";
                NSLog(@"[BJBLE] ⚠️ 初始状态为空");
            }
            BJStartRefreshTimer();
        });
}
