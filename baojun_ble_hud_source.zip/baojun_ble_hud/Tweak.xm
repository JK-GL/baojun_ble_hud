#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

// ============================================================
// MARK: - 视图层级探测器
// ============================================================

static void BJLogView(UIView *view, int depth, NSMutableString *log) {
    if (!view || depth > 15) return;

    CGRect frame = view.frame;
    CGRect bounds = view.bounds;

    // 获取背景色
    NSString *bgColor = @"nil";
    if (view.backgroundColor) {
        CGFloat r, g, b, a;
        [view.backgroundColor getRed:&r green:&g blue:&b alpha:&a];
        bgColor = [NSString stringWithFormat:@"rgba(%.0f,%.0f,%.0f,%.2f)", r*255, g*255, b*255, a];
    }

    // 获取 class 名称
    NSString *className = NSStringFromClass([view class]);

    // 获取 tag
    long tag = view.tag;

    // 获取 superview 类名
    NSString *superName = view.superview ? NSStringFromClass([view.superview class]) : @"nil";

    // 缩进
    NSString *indent = @"";
    for (int i = 0; i < depth; i++) indent = [indent stringByAppendingString:@"  "];

    // 拼接日志
    [log appendFormat:@"%@[%d] %@ frame={{%.1f,%.1f,%.1f,%.1f}} bounds={{%.1f,%.1f,%.1f,%.1f}} bg=%@ tag=%ld subviews=%lu super=%@\n",
        indent, depth, className,
        frame.origin.x, frame.origin.y, frame.size.width, frame.size.height,
        bounds.origin.x, bounds.origin.y, bounds.size.width, bounds.size.height,
        bgColor, tag, (unsigned long)view.subviews.count, superName];

    // 特殊标记
    if ([view isKindOfClass:[UINavigationBar class]]) {
        [log appendFormat:@"%@  >>> 这是 UINavigationBar! <<<\n", indent];
    }
    if ([view isKindOfClass:[UITabBar class]]) {
        [log appendFormat:@"%@  >>> 这是 UITabBar! <<<\n", indent];
    }
    if ([view isKindOfClass:[UIScrollView class]]) {
        [log appendFormat:@"%@  >>> 这是 UIScrollView! contentSize={%.1f,%.1f} <<<\n", indent,
            [(UIScrollView *)view contentSize].width, [(UIScrollView *)view contentSize].height];
    }
    if ([view isKindOfClass:[UICollectionView class]]) {
        [log appendFormat:@"%@  >>> 这是 UICollectionView! <<<\n", indent];
    }
    if ([view isKindOfClass:[UITableView class]]) {
        [log appendFormat:@"%@  >>> 这是 UITableView! <<<\n", indent];
    }
    if ([className containsString:@"Flutter"]) {
        [log appendFormat:@"%@  >>> 这是 Flutter 相关视图! <<<\n", indent];
    }
    if ([className containsString:@"TabBar"] || [className containsString:@"tabBar"]) {
        [log appendFormat:@"%@  >>> 这是 TabBar 相关! <<<\n", indent];
    }
    if ([className containsString:@"Nav"] || [className containsString:@"nav"]) {
        [log appendFormat:@"%@  >>> 这是 Navigation 相关! <<<\n", indent];
    }

    // 递归子视图
    for (UIView *sub in view.subviews) {
        BJLogView(sub, depth + 1, log);
    }
}

static void BJProbeViews(void) {
    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop

    if (!keyWindow) {
        NSLog(@"[BJBLE] === 探测失败: 未找到 keyWindow ===");
        return;
    }

    NSLog(@"[BJBLE] ==============================");
    NSLog(@"[BJBLE] === 开始视图层级探测 ===");
    NSLog(@"[BJBLE] ==============================");
    NSLog(@"[BJBLE] keyWindow: %@", keyWindow);
    NSLog(@"[BJBLE] keyWindow frame: {{%.1f,%.1f,%.1f,%.1f}}",
        keyWindow.frame.origin.x, keyWindow.frame.origin.y,
        keyWindow.frame.size.width, keyWindow.frame.size.height);
    NSLog(@"[BJBLE] keyWindow subviews count: %lu", (unsigned long)keyWindow.subviews.count);
    NSLog(@"[BJBLE] ---");

    NSMutableString *log = [NSMutableString string];
    BJLogView(keyWindow, 0, log);

    // 分行输出
    NSArray *lines = [log componentsSeparatedByString:@"\n"];
    for (NSString *line in lines) {
        if (line.length > 0) {
            NSLog(@"[BJBLE] %@", line);
        }
    }

    NSLog(@"[BJBLE] ==============================");
    NSLog(@"[BJBLE] === 视图探测完成 ===");
    NSLog(@"[BJBLE] ==============================");
}

// ============================================================
// MARK: - Hooks
// ============================================================

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJIsTarget()) return;

    // 延时 3 秒等 App 完全加载
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            NSLog(@"[BJBLE] === App 激活，开始探测视图 ===");
            BJProbeViews();
        });
}
%end

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJIsTarget()) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            NSLog(@"[BJBLE] === FlutterVC 出现，开始探测视图 ===");
            BJProbeViews();
        });
}
%end

%ctor {
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] ====== 视图探测插件已加载 ======");
    NSLog(@"[BJBLE] Bundle: %@", [NSBundle mainBundle].bundleIdentifier);
}
