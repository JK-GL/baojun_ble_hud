#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

static UIWindow *gKeyWindow = nil;

static void BJShowAlert(NSString *title, NSString *msg) {
    if (!gKeyWindow) return;
    UIAlertController *a = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [gKeyWindow.rootViewController presentViewController:a animated:YES completion:nil];
}

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;

    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    NSLog(@"[BJBLE] bundleId=%@", bid);
    if (![bid isEqualToString:@"com.sgmw.baojunplus"]) return;

    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { gKeyWindow = w; break; }
    }
    if (!gKeyWindow) { NSLog(@"[BJBLE] no keyWindow"); return; }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            BJShowAlert(@"Tweak OK", @"点击查看视图层级");
        });
}
%end

%ctor {
    NSLog(@"[BJBLE] loaded bid=%@", [NSBundle mainBundle].bundleIdentifier);
}
