#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;

    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    NSLog(@"[BJBLE] applicationDidBecomeActive, bundleId=%@", bid);

    if (![bid isEqualToString:@"com.sgmw.baojunplus"]) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            NSLog(@"[BJBLE] 弹出 Alert");

            UIAlertController *alert = [UIAlertController
                alertControllerWithTitle:@"Tweak 已加载"
                message:@"点击确定查看视图层级"
                preferredStyle:UIAlertControllerStyleAlert];

            [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault
                handler:^(UIAlertAction *action) {
                    NSMutableString *log = [NSMutableString string];
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
                    NSArray *windows = [UIApplication sharedApplication].windows;
                    for (UIWindow *w in windows) {
                        [log appendFormat:@"Window: %@ frame={{%.0f,%.0f,%.0f,%.0f}} subviews=%lu\n",
                            NSStringFromClass([w class]),
                            w.frame.origin.x, w.frame.origin.y,
                            w.frame.size.width, w.frame.size.height,
                            (unsigned long)w.subviews.count];
                        for (UIView *v in w.subviews) {
                            [log appendFormat:@"  %@ frame={{%.0f,%.0f,%.0f,%.0f}} subviews=%lu\n",
                                NSStringFromClass([v class]),
                                v.frame.origin.x, v.frame.origin.y,
                                v.frame.size.width, v.frame.size.height,
                                (unsigned long)v.subviews.count];
                        }
                    }
#pragma clang diagnostic pop

                    UIAlertController *logAlert = [UIAlertController
                        alertControllerWithTitle:@"View Hierarchy"
                        message:log
                        preferredStyle:UIAlertControllerStyleAlert];
                    [logAlert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
                    UIViewController *root = [UIApplication sharedApplication].keyWindow.rootViewController;
#pragma clang diagnostic pop
                    [root presentViewController:logAlert animated:YES completion:nil];
                }];

            [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
            UIViewController *root = [UIApplication sharedApplication].keyWindow.rootViewController;
#pragma clang diagnostic pop
            [root presentViewController:alert animated:YES completion:nil];
        });
}
%end

%ctor {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    NSLog(@"[BJBLE] 插件已加载, bundleId=%@", bid);
}
