#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

static BOOL BJIsTarget(void) {
    NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
    return [bid isEqualToString:@"com.sgmw.baojunplus"];
}

static UITextView *gLogView = nil;
static UIView *gPanel = nil;

// ============================================================
// MARK: - 视图层级探测
// ============================================================

static void BJLogView(UIView *view, int depth, NSMutableString *log) {
    if (!view || depth > 12) return;

    CGRect f = view.frame;
    NSString *cls = NSStringFromClass([view class]);
    NSString *bg = @"nil";
    if (view.backgroundColor) {
        CGFloat r, g, b, a;
        [view.backgroundColor getRed:&r green:&g blue:&b alpha:&a];
        bg = [NSString stringWithFormat:@"rgba(%.0f,%.0f,%.0f,%.2f)", r*255, g*255, b*255, a];
    }

    NSString *indent = @"";
    for (int i = 0; i < depth; i++) indent = [indent stringByAppendingString:@"  "];

    [log appendFormat:@"%@[%d] %@ {{%.0f,%.0f,%.0f,%.0f}} bg=%@ tag=%ld sub=%lu\n",
        indent, depth, cls, f.origin.x, f.origin.y, f.size.width, f.size.height,
        bg, (long)view.tag, (unsigned long)view.subviews.count];

    if ([view isKindOfClass:[UINavigationBar class]])
        [log appendFormat:@"%@  >>> UINavigationBar <<<\n", indent];
    if ([view isKindOfClass:[UITabBar class]])
        [log appendFormat:@"%@  >>> UITabBar <<<\n", indent];
    if ([view isKindOfClass:[UIScrollView class]])
        [log appendFormat:@"%@  >>> UIScrollView contentSize={%.0f,%.0f} <<<\n", indent,
            [(UIScrollView *)view contentSize].width, [(UIScrollView *)view contentSize].height];
    if ([cls containsString:@"Flutter"])
        [log appendFormat:@"%@  >>> Flutter <<<\n", indent];
    if ([cls containsString:@"TabBar"] || [cls containsString:@"tabBar"])
        [log appendFormat:@"%@  >>> TabBar <<<\n", indent];

    for (UIView *sub in view.subviews) {
        BJLogView(sub, depth + 1, log);
    }
}

static NSString *BJProbeViews(void) {
    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop
    if (!keyWindow) return @"未找到 keyWindow";

    NSMutableString *log = [NSMutableString string];
    [log appendFormat:@"keyWindow: {{%.0f,%.0f,%.0f,%.0f}}\n",
        keyWindow.frame.origin.x, keyWindow.frame.origin.y,
        keyWindow.frame.size.width, keyWindow.frame.size.height];
    [log appendString:@"========================\n"];
    BJLogView(keyWindow, 0, log);
    return log;
}

// ============================================================
// MARK: - 显示日志面板
// ============================================================

static void BJShowLogPanel(NSString *log) {
    if (gPanel) return;

    CGFloat sw = [UIScreen mainScreen].bounds.size.width;
    CGFloat sh = [UIScreen mainScreen].bounds.size.height;

    // 半透明背景
    gPanel = [[UIView alloc] initWithFrame:CGRectMake(0, sh * 0.3, sw, sh * 0.7)];
    gPanel.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.92];
    gPanel.layer.cornerRadius = 16;
    gPanel.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;

    // 标题
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(16, 8, sw - 100, 20)];
    title.text = @"📋 视图层级 (可复制)";
    title.textColor = [UIColor whiteColor];
    title.font = [UIFont boldSystemFontOfSize:13];
    [gPanel addSubview:title];

    // 关闭按钮
    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    closeBtn.frame = CGRectMake(sw - 50, 6, 40, 24);
    [closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [closeBtn setTitleColor:[UIColor systemRedColor] forState:UIControlStateNormal];
    closeBtn.titleLabel.font = [UIFont systemFontOfSize:13];
    [closeBtn addTarget:self action:@selector(BJClosePanel) forControlEvents:UIControlEventTouchUpInside];
    [gPanel addSubview:closeBtn];

    // 日志文本 (可复制)
    gLogView = [[UITextView alloc] initWithFrame:CGRectMake(8, 32, sw - 16, sh * 0.7 - 44)];
    gLogView.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.1];
    gLogView.textColor = [UIColor greenColor];
    gLogView.font = [UIFont fontWithName:@"Menlo" size:10];
    gLogView.editable = NO;
    gLogView.text = log;
    [gPanel addSubview:gLogView];

    // 复制按钮
    UIButton *copyBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    copyBtn.frame = CGRectMake(sw - 120, 6, 60, 20);
    [copyBtn setTitle:@"📋 复制" forState:UIControlStateNormal];
    [copyBtn setTitleColor:[UIColor systemGreenColor] forState:UIControlStateNormal];
    copyBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    [copyBtn addTarget:self action:@selector(BJCopyLog) forControlEvents:UIControlEventTouchUpInside];
    [gPanel addSubview:copyBtn];

    // 添加到窗口
    UIWindow *keyWindow = nil;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { keyWindow = w; break; }
    }
#pragma clang diagnostic pop
    if (keyWindow) [keyWindow addSubview:gPanel];
}

// ============================================================
// MARK: - 关闭面板
// ============================================================

%hook UIButton
- (void)sendAction:(SEL)action to:(id)target forEvent:(UIEvent *)event {
    // 检查是否是关闭按钮
    if ([self.superview isKindOfClass:[UIView class]]) {
        UIView *panel = self.superview;
        if (panel == gPanel) {
            [gPanel removeFromSuperview];
            gPanel = nil;
            gLogView = nil;
            return;
        }
    }
    %orig;
}
%end

// ============================================================
// MARK: - Hooks
// ============================================================

%hook UIApplication
- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;
    if (!BJIsTarget()) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            NSString *log = BJProbeViews();
            BJShowLogPanel(log);
        });
}
%end

%hook FlutterViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (!BJIsTarget()) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            if (gPanel) return; // 已经显示了
            NSString *log = BJProbeViews();
            BJShowLogPanel(log);
        });
}
%end

%ctor {
    if (!BJIsTarget()) return;
    NSLog(@"[BJBLE] ====== 视图探测插件已加载 ======");
}
